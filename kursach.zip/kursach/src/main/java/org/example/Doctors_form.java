package org.example;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static org.example.Disease.showDiseases;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Doctors_form extends JFrame {
    private static final Logger log = Logger.getLogger(Doctors_form.class.getName());
    private static JComboBox<String> departmentComboBox;
    private static JButton showDiseasesButton;
    private static JButton showDoctorsButton;
    private JButton backButton;
    private int dep_id;
    private static JPanel contentPanel;

    /**
     * Метод для отображения окна врачей и болезней
     */
    public void show_form() {
        log.debug("Отображение окна врачей и отделений");
        JFrame booklist = new JFrame("Отделения");
        booklist.setSize(400, 400);
        booklist.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());
        booklist.setLocationRelativeTo(null);
        JComboBox departmentComboBox = Department.make_combo_box();

        showDiseasesButton = new JButton("Показать болезни");
        showDoctorsButton = new JButton("Показать врачей");
        backButton = new JButton("Назад");


        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажата кнопка 'Назад'");
                if (booklist != null) {
                    booklist.dispose();
                }
                Appointment_form form = new Appointment_form();
                form.show_start();
            }
        });

        showDiseasesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажата кнопка 'Показать болезни'");
                if (booklist != null) {
                    booklist.dispose();
                }
                String selectedDepartment = (String) departmentComboBox.getSelectedItem();
                if (selectedDepartment.equals("Все"))
                {
                    dep_id = -1;
                }
                else
                {
                    dep_id = Department.getIdByName(selectedDepartment);
                }
                showDiseases(dep_id);
            }
        });

        showDoctorsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажата кнопка 'Показать врачей'");
                if (booklist != null) {
                    booklist.dispose();
                }
                String selectedDepartment = (String) departmentComboBox.getSelectedItem();
                if (selectedDepartment.equals("Все"))
                {
                    dep_id = -1;
                }
                else
                {
                    dep_id = Department.getIdByName(selectedDepartment);
                }
                Doctor doctor = new Doctor();
                try {
                    doctor.showDoctors(dep_id);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        panel.add(departmentComboBox);
        panel.add(showDiseasesButton);
        panel.add(showDoctorsButton);
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.add(backButton);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        contentPanel.add(panel, BorderLayout.CENTER);
        contentPanel.add(panel, BorderLayout.NORTH);

        getContentPane().add(contentPanel);
        booklist.add(panel);
        booklist.setVisible(true);

    }


    /**
     * Метод для отображения формы добавления нового врача
     */
    public Doctor add_doctor_form(DefaultTableModel model, int department_id) {
        log.info("Открыта форма добавления нового врача");
        JFrame booklist = new JFrame("Добавить врача");
        booklist.setSize(400, 400);
        booklist.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        booklist.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(9, 2, 10, 10));

        panel.add(new JLabel("Фамилия:"));
        JTextField lastNameField = new JTextField();
        panel.add(lastNameField);

        panel.add(new JLabel("Имя:"));
        JTextField firstNameField = new JTextField();
        panel.add(firstNameField);

        panel.add(new JLabel("Отчество:"));
        JTextField middleNameField = new JTextField();
        panel.add(middleNameField);

        panel.add(new JLabel("Пол:"));
        JComboBox<String> genderComboBox = new JComboBox<>(new String[]{"Муж", "Жен"});
        panel.add(genderComboBox);

        panel.add(new JLabel("Возраст:"));
        DigitOnlyTextField ageField = new DigitOnlyTextField();
        panel.add(ageField);

        panel.add(new JLabel("Кабинет:"));
        DigitOnlyTextField officeField = new DigitOnlyTextField();
        panel.add(officeField);

        panel.add(new JLabel("Специализация:"));
        JTextField specializationField = new JTextField();
        panel.add(specializationField);

        JButton addButton = new JButton("Добавить");
        panel.add(addButton);

        booklist.add(panel);
        booklist.setVisible(true);

        Doctor doctor = new Doctor();
        doctor.setPerson(new Person());
        addButton.addActionListener(e -> {
            if (isAllFieldsFilled(lastNameField, firstNameField, ageField, officeField, specializationField)) {
                try {
                    log.debug("Начато добавление нового врача");
                    doctor.getPerson().setSurame(lastNameField.getText());
                    doctor.getPerson().setName(firstNameField.getText());
                    doctor.getPerson().setLastName(middleNameField.getText());
                    doctor.getPerson().setSex((String) genderComboBox.getSelectedItem());
                    doctor.getPerson().setFullname();
                    doctor.getPerson().setAge(Integer.valueOf(ageField.getText()));
                    doctor.setCabinet(Integer.parseInt(officeField.getText()));
                    Department dep = new Department();
                    dep.setDep(department_id);
                    doctor.setDepartment(dep);
                    doctor.setSpecialty(specializationField.getText());
                    Schedule sch = new Schedule();
                    sch.setSch(doctor.add_sch());
                    doctor.setSchedule(sch);
                    List<Doctor> doctors = new ArrayList<>();
                    doctors.add(doctor);
                    String[] fields = {"", doctor.getPerson().getFullname(), doctor.getSpecialty(), String.valueOf(doctor.getCabinet())};
                    model.addRow(fields);
                    booklist.dispose();
                    log.debug("Успешно завершено добавление нового врача");

            } catch(Exception ex){
                log.warn("Ошибка добавления нового врача", ex);
                ex.printStackTrace();
            }
        }
        else {
            JOptionPane.showMessageDialog(booklist, "Заполните все обязательные поля", "Предупреждение", JOptionPane.WARNING_MESSAGE);
        }
    });

    return doctor;
}

    private static boolean isAllFieldsFilled(JTextField lastName, JTextField firstName, DigitOnlyTextField age, DigitOnlyTextField office, JTextField specialization) {
        return !lastName.getText().isEmpty() && !firstName.getText().isEmpty() && !age.getText().isEmpty() && !office.getText().isEmpty() && !specialization.getText().isEmpty();
    }


    public static class DigitOnlyTextField extends JTextField {
        public DigitOnlyTextField() {
            addKeyListener(new KeyListener() {
                @Override
                public void keyTyped(KeyEvent e) {
                    char c = e.getKeyChar();
                    if (!Character.isDigit(c)) {
                        e.consume(); // игнорируем введенный символ, если это не цифра
                    }
                }

                @Override
                public void keyPressed(KeyEvent e) {
                    // Ничего не делаем при нажатии клавиши
                }

                @Override
                public void keyReleased(KeyEvent e) {
                    // Ничего не делаем при отпускании клавиши
                }
            });
        }
    }


}


