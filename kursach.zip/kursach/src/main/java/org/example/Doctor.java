package org.example;
import javax.persistence.*;
import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.*;
import java.util.*;
import java.util.List;
import org.apache.log4j.Logger;
@Entity
@Table(name = "doctors")

public class Doctor {
    private static final Logger log = Logger.getLogger(Doctor.class.getName());
    @Id
    @Column(name = "d_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer d_id;
    private List<Doctor> new_doctors = new ArrayList<>();


    public int getID() {
        return d_id;
    }

    public void setID(int d_id) {
        this.d_id = d_id;
    }

    private String specialty;

    @Column(name = "doctor_specialty")
    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    private Integer cabinet;

    @Column(name = "doctor_cabinet")
    public int getCabinet() {
        return cabinet;
    }

    public void setCabinet(int cabinet) {
        this.cabinet = cabinet;
    }

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "name", column = @Column(name = "d_name")),
            @AttributeOverride(name = "last_name", column = @Column(name = "d_last_name")),
            @AttributeOverride(name = "surname", column = @Column(name = "d_surname")),
            @AttributeOverride(name = "sex", column = @Column(name = "doctor_sex")),
            @AttributeOverride(name = "age", column = @Column(name = "doctor_age"))
    })

    private Person person;

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    @ManyToOne
    @JoinColumn(name = "doctor_department_id")

    private Department department;

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    @ManyToOne
    @JoinColumn(name = "doctor_schedule_id")

    private Schedule schedule;

    public Schedule getSchedule() {
        return schedule;
    }

    public void setSchedule(Schedule schedule) {
        this.schedule = schedule;
    }


    public void setDoctor(int id) {
        log.debug("Создан объект класса Doctor");
        this.setID(id);
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC", "root", "pipopolam")) {
            String sqlQuery = "SELECT d_name, d_surname, d_last_name, " +
                    "doctor_sex, doctor_age, doctor_cabinet, doctor_department_id, " +
                    "doctor_schedule_id, doctor_specialty FROM doctors WHERE d_id = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setInt(1, id);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        this.setPerson(new Person());
                        this.person.setName(resultSet.getString("d_name"));
                        this.person.setLastName(resultSet.getString("d_last_name"));
                        this.person.setSurame(resultSet.getString("d_surname"));
                        this.person.setFullname();
                        this.person.setSex(resultSet.getString("doctor_sex"));
                        this.person.setAge(resultSet.getInt("doctor_age"));
                        this.setCabinet(resultSet.getInt("doctor_cabinet"));
                        Department dep = new Department();
                        dep.setDep(resultSet.getInt("doctor_department_id"));
                        this.setDepartment(dep);
                        Schedule schedule = new Schedule();
                        schedule.setSch(resultSet.getInt("doctor_schedule_id"));
                        this.setSchedule(schedule);
                        this.setSpecialty(resultSet.getString("doctor_specialty"));
                    }
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }

    public static int getIdByName(String doctor_fullname) {
        log.debug("Начато получение ID врача по имени");
        int doctorId = -1;
        String[] nameComponents = doctor_fullname.split("\\s+");

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC", "root", "pipopolam")) {
            String doctor_name="";
            String doctor_last_name="";
            String doctor_surname="";
            if (nameComponents.length >= 3)
            {
                doctor_name = nameComponents[0];
                doctor_last_name = nameComponents[1];
                doctor_surname = nameComponents[2];
            }
            else if (nameComponents.length == 2) {
                doctor_name = nameComponents[0];
                doctor_last_name = "";
                doctor_surname = nameComponents[1];
            }
            else if (nameComponents.length == 1) {
                doctor_name = nameComponents[0];
                doctor_last_name = "";
                doctor_surname = "";
            }
            else {
                doctor_name = "";
                doctor_last_name = "";
                doctor_surname = "";
            }


            String sqlQuery = "SELECT d_id FROM doctors WHERE d_name = ? and d_last_name = ? and d_surname = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setString(1, doctor_name);
                preparedStatement.setString(2, doctor_last_name);
                preparedStatement.setString(3, doctor_surname);


                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        doctorId = resultSet.getInt("d_id");
                    }
                }

                log.debug("Успешно завершено получение ID врача по имени");
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            log.warn("Ошибка получения ID врача по имени", e);
            e.printStackTrace();
        }

        return doctorId;
    }

    public static String getNameById(int id) {
        log.debug("Начато получение имени врача по ID");
        String doctorName = null;
        String doctorLastName = null;
        String doctorSurname = null;

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC", "root", "pipopolam")) {
            String sqlQuery = "SELECT d_name, d_last_name, d_surname FROM doctors WHERE d_id = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setInt(1, id);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        doctorName = resultSet.getString("d_name");
                        doctorLastName = resultSet.getString("d_last_name");
                        doctorSurname = resultSet.getString("d_surname");
                    }
                }

                log.debug("Успешно выполнено получение имени врача по ID");
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            log.warn("Ошибка поулчения имени врача по ID", e);
            e.printStackTrace();
        }

        return doctorName + " " + doctorLastName + " " + doctorSurname;
    }



    void showDoctors(int dep_id) throws SQLException {
        log.info("Отображение редактора врачей");
        Doctor selectedDoctor = new Doctor();
        JFrame booklist = new JFrame("Врачи");
        booklist.setSize(700, 400);
        booklist.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        booklist.setLocationRelativeTo(null);

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());

        String[] columnNames = {"ID","ФИО", "Специальность", "Кабинет"};
        Object[][] data = {};
        DefaultTableModel model = new DefaultTableModel(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0;
            }
        };

        JTable doctorsTable = new JTable(model);
        doctorsTable.getColumnModel().getColumn(3).setCellEditor(createCellEditor());
        JButton showScheduleButton = new JButton("Показать расписание");
        fill_table(model, dep_id);
        JPanel panel = new JPanel(new BorderLayout());
        JButton backButton = new JButton("Назад");
        JButton add = new JButton("Добавить");
        JButton delete = new JButton("Удалить");
        JButton save = new JButton("Сохранить");
        JButton update = new JButton("Обновить");
        EnterListener(model, doctorsTable, booklist);
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажата кнопка 'Назад'");
                if (booklist != null) {
                    booklist.dispose();
                }
                Doctors_form form = new Doctors_form();
                form.show_form();
            }
        });

        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажата кнопка 'Добавить'");
                if (dep_id != -1) {
                    Doctors_form form = new Doctors_form();
                    Doctor new_doctor = new Doctor();
                    new_doctor = form.add_doctor_form(model, dep_id);
                    new_doctors.add(new_doctor);
                }
                else {
                    JOptionPane.showMessageDialog(booklist, "Добавление возможно только в конкретное отделение");
                }

            }
        });

        save.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Doctor doctor = new Doctor();
                log.debug("Нажата кнопка 'Сохранить'");
                try {
                    doctor.export_to_db(model, new_doctors, dep_id);
                    JOptionPane.showMessageDialog(booklist, "Сохранено");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(booklist, "Ошибка сохранения.\nПроверьте правильность введенных данных");
                    ex.printStackTrace();
                }
            }
        });

        delete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажата кнопка 'Удалить'");
                boolean flag = Are_You_Sure.showMessage();
                if (flag) {
                    try {
                        int row = doctorsTable.getSelectedRow();

                        if (row != -1) {
                            String doctorName = model.getValueAt(row, 1).toString();

                            int doctorId = Doctor.getIdByName(doctorName);
                            Doctor.delete_doctor(doctorId);

                            model.removeRow(row);

                            JOptionPane.showMessageDialog(booklist, "Доктор и связанные записи удалены успешно");
                        }
                        log.debug("Записи о враче успешно удалены");

                    } catch (Exception ex) {
                        log.warn("Ошибка удаления записей о враче", ex);
                        JOptionPane.showMessageDialog(booklist, "Ошибка удаления");
                        ex.printStackTrace();
                    }
                }
            }
        });

        update.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажата кнопка 'Обновить'");
                fill_table(model, dep_id);
                JOptionPane.showMessageDialog(booklist, "Информация успешно обновлена");
            }
        });

        panel.add(new JScrollPane(doctorsTable), BorderLayout.CENTER);
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.add(save);
        bottomPanel.add(delete);
        bottomPanel.add(add);
        bottomPanel.add(update);
        bottomPanel.add(showScheduleButton);
        bottomPanel.add(backButton);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        contentPanel.add(panel, BorderLayout.CENTER);
        booklist.add(contentPanel);
        booklist.setVisible(true);


        doctorsTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = doctorsTable.getSelectedRow();
                if (selectedRow != -1) {
                    String doctorName = doctorsTable.getValueAt(selectedRow, 1).toString();
                    selectedDoctor.setDoctor(selectedDoctor.getIdByName(doctorName));

                }
            }
        });


        showScheduleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажата кнопка 'Показать расписание'");
                try {
                    Schedule schedule = new Schedule();
                    schedule.showSchedules(selectedDoctor);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    throw new RuntimeException(ex);
                }
            }
        });


    }


    private DefaultCellEditor createCellEditor() {
        JTextField textField = new JTextField();

        textField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume(); // Отменить ввод, если символ не цифра
                }
            }
        });

        return new DefaultCellEditor(textField);
    }


    public void EnterListener(DefaultTableModel model, JTable doctors, JFrame booklist)
    {
        model.addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                if (e.getType() == TableModelEvent.UPDATE) {
                    log.debug("Начато изменение записи в бд");
                    int selectedRow = doctors.getSelectedRow();
                    if (selectedRow != -1) {
                        String[] editedRow = new String[model.getColumnCount()];
                        for (int i = 0; i < model.getColumnCount(); i++) {
                            editedRow[i] = (String) doctors.getValueAt(selectedRow, i);
                        }

                        try {
                            if (!Objects.equals(editedRow[0], ""))
                            {
                                Doctor.save_after_edit(editedRow, booklist);
                            }

                        } catch (SQLException ex) {
                            throw new RuntimeException(ex);
                        }
                    }
                }
            }
        });

    }

    public static void save_after_edit(String[] row, JFrame booklist) throws SQLException {
        int doc_id = -1;
        Doctor doc = new Doctor();
        doc_id = Integer.parseInt(row[0]);
        doc.setDoctor(doc_id);
        String[] fullname = row[1].split(" ");
        doc.person.setName(fullname[0]);
        if (fullname.length == 3) {
            doc.person.setLastName(fullname[1]);
            doc.person.setSurame(fullname[2]);
        }
        else {
            doc.person.setSurame(fullname[1]);
            doc.person.setLastName("");
        }

        doc.person.setFullname();
        doc.setCabinet(Integer.parseInt(row[3]));
        doc.setSpecialty(row[2]);

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            String updateQuery = "UPDATE doctors SET d_name=?, d_last_name=?, d_surname=?, doctor_cabinet=?, doctor_specialty=? WHERE d_id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
                preparedStatement.setString(1, doc.person.getName());
                preparedStatement.setString(2, doc.person.getLastName());
                preparedStatement.setString(3, doc.person.getSurame());
                preparedStatement.setInt(4, doc.getCabinet());
                preparedStatement.setString(5, doc.getSpecialty());
                preparedStatement.setInt(6, doc_id);

                int rowsUpdated = preparedStatement.executeUpdate();

                if (rowsUpdated > 0) {
                    log.debug("Запись успешно обновлена");;
                }
            }
        } catch (SQLException e) {
            log.warn("Ошибка обновления записи", e);
            JOptionPane.showMessageDialog(booklist, "Ошибка. Проверьте правильность введенных данных");
            e.printStackTrace();
        }
    }

    public static void delete_doctor(int doctor_id) throws SQLException {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            connection.setAutoCommit(false);

            try {

                String deleteAppointmentsQuery = "DELETE FROM appointments WHERE appointment_doctor_id = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(deleteAppointmentsQuery)) {
                    preparedStatement.setInt(1, doctor_id);
                    preparedStatement.executeUpdate();
                }

                String deletePapersQuery = "DELETE FROM papers WHERE paper_doctor_id = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(deletePapersQuery)) {
                    preparedStatement.setInt(1, doctor_id);
                    preparedStatement.executeUpdate();
                }

                String deleteSchedulesQuery = "DELETE FROM schedule WHERE id = (SELECT doctor_schedule_id FROM doctors WHERE d_id = ?)";
                try (PreparedStatement preparedStatement = connection.prepareStatement(deleteSchedulesQuery)) {
                    preparedStatement.setInt(1, doctor_id);
                    preparedStatement.executeUpdate();
                }

                String deleteDoctorQuery = "DELETE FROM doctors WHERE d_id = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(deleteDoctorQuery)) {
                    preparedStatement.setInt(1, doctor_id);
                    preparedStatement.executeUpdate();
                }

                connection.commit();
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            }
        }
    }

    public static void export_to_db(DefaultTableModel model, List<Doctor> new_doctors, int dep_id) throws SQLException {
        log.debug("Начат экспорт таблицы врачей в базу данных");
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {

            for (Doctor new_doctor : new_doctors) {

                String insertQuery = "INSERT INTO doctors (d_name, d_last_name, d_surname, doctor_sex, doctor_age, doctor_cabinet, doctor_department_id, doctor_specialty, doctor_schedule_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

                try (PreparedStatement insertStatement = connection.prepareStatement(insertQuery)) {
                    insertStatement.setString(1, new_doctor.person.getName());
                    insertStatement.setString(2, new_doctor.person.getLastName());
                    insertStatement.setString(3, new_doctor.person.getSurame());
                    insertStatement.setString(4, new_doctor.person.getSex());
                    insertStatement.setInt(5, new_doctor.person.getAge());
                    insertStatement.setInt(6, new_doctor.getCabinet());
                    insertStatement.setInt(7, dep_id);
                    insertStatement.setString(8, new_doctor.getSpecialty());
                    insertStatement.setInt(9, new_doctor.getSchedule().getID());

                    insertStatement.executeUpdate();

                }
            }
            log.debug("Успешно завершен экспорт врачей в базу данных");

            new_doctors.clear();
        } catch (SQLException ex) {
            ex.printStackTrace();
            log.warn("Ошибка экспорта врачей в базу данных", ex);
            throw new RuntimeException(ex);
        }
        }

        void fill_table(DefaultTableModel model, int dep_id)
        {
            int rows = model.getRowCount();
            for (int i = 0; i < rows; i++) {
                model.removeRow(0);
            }
            log.debug("Начато заполнение таблицы врачей");

            try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
                String sqlQuery = "SELECT d_id, doctor_cabinet, doctor_specialty, " +
                        "CONCAT(d_name, ' ', d_last_name, ' ', d_surname) AS doctor_name FROM doctors";

                if (dep_id != -1) {
                    sqlQuery += " WHERE doctor_department_id = ?";
                }

                PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);

                if (dep_id != -1) {
                    preparedStatement.setInt(1, dep_id);
                }


                ResultSet resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    String doctor_id = resultSet.getString(1);
                    String doctor_cabinet = resultSet.getString(2);
                    String doctor_speciality = resultSet.getString(3);
                    String doctorName = resultSet.getString(4);

                    String[] fields = {doctor_id, doctorName, doctor_speciality, doctor_cabinet};
                    model.addRow(fields);
                }

                log.debug("Успешно выполнено заполнение таблицы врачей");

            } catch (SQLException e) {
                log.warn("Ошибка заполнения таблицы врачей", e);
                e.printStackTrace();
            }
        }

    static JComboBox make_combo_box()
    {
        log.debug("Начата выгрузка врачей");
        String[] departments = {};
        JComboBox cb = new JComboBox<>(departments);
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            Statement statement = connection.createStatement();
            String sqlQuery = "SELECT d_name, d_last_name, d_surname FROM doctors ";

            ResultSet resultSet = statement.executeQuery(sqlQuery);

            while (resultSet.next()) {
                String d_fullname = resultSet.getString(1) + " " + resultSet.getString(2) + " " + resultSet.getString(3);
                cb.addItem(d_fullname);
            }
            log.debug("Успешно завершена выгрузка пациентов");
        } catch (SQLException e) {
            log.warn("Ошибка выгрузки пациентов", e);
            e.printStackTrace();
        }

        return cb;
    }

    int add_sch() {
        int scheduleId=-1;
        Schedule schedule = new Schedule();
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            String updateQuery = "INSERT INTO schedule (monday, tuesday, wednesday, thursday, friday, saturday, sunday) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery, Statement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setString(1, "8:00");
                preparedStatement.setString(2, "8:00");
                preparedStatement.setString(3, "8:00");
                preparedStatement.setString(4, "8:00");
                preparedStatement.setString(5, "8:00");
                preparedStatement.setString(6, "8:00");
                preparedStatement.setString(7, "8:00");

                int rowsUpdated = preparedStatement.executeUpdate();

                if (rowsUpdated > 0) {
                    ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                    if (generatedKeys.next()) {
                        scheduleId = generatedKeys.getInt(1);
                        log.debug("Запись успешно обновлена");
                        return scheduleId;
                    }
                }
            }
        } catch (SQLException e) {
            log.warn("Ошибка обновления записи", e);
            e.printStackTrace();
        }

        return scheduleId;
    }


}



