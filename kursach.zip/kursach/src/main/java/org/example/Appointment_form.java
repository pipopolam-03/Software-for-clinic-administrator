package org.example;

import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;
import java.text.ParseException;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Appointment_form {
    private static final Logger log = Logger.getLogger(Appointment_form.class.getName());
    private JFrame clinicFrame;
    private static JLabel welcomeLabel;

    private DefaultTableModel model;
    private JButton save;
    private JButton add;
    private JButton delete;
    private JButton update;
    private JToolBar toolBar;
    private JScrollPane scroll;
    private JTable appointments;

    private static JButton showApps;
    private static JButton showDeps;
    private static JButton back;
    private static JButton showPaper;
    private static JButton showPatients;

    public static void main(String[] args) {
        PropertyConfigurator.configure("C:\\Users\\pipop\\IdeaProjects\\kursach\\log4j.properties");
        log.debug("Приложение открыто");
        Appointment_form appointmentForm = new Appointment_form();
        appointmentForm.show_start();
    }

    public void show_start() {
        log.info("Отображение начального экрана");
        clinicFrame = new JFrame("Поликлиника");
        clinicFrame.setSize(420, 400);
        clinicFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        clinicFrame.setLocationRelativeTo(null);

        welcomeLabel = new JLabel("Добро пожаловать в поликлинику №666", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(85, 0, 0, 0));

        showApps = createButton("Редактор записей", e -> appsButtonAction());
        showDeps = createButton("Врачи и болезни", e -> depsButtonAction());
        showPaper = createButton("Печать справки", e -> paperButtonAction());
        showPatients = createButton("Показать пациентов", e -> patientsButtonAction());

        JPanel buttonPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);

        buttonPanel.add(showApps, gbc);
        gbc.gridy = 1;
        buttonPanel.add(showDeps, gbc);
        gbc.gridy = 2;
        buttonPanel.add(showPaper, gbc);
        gbc.gridy = 3;
        buttonPanel.add(showPatients, gbc);

        clinicFrame.add(buttonPanel, BorderLayout.CENTER);
        clinicFrame.add(welcomeLabel, BorderLayout.NORTH);

        clinicFrame.setLocationRelativeTo(null);
        clinicFrame.setVisible(true);
    }

    private JButton createButton(String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.addActionListener(listener);
        return button;
    }

    private JButton createButtonWithImage(String iconPath, ActionListener listener) {
        ImageIcon icon = new ImageIcon(iconPath);
        JButton button = new JButton(icon);
        button.addActionListener(listener);
        return button;
    }

    private void appsButtonAction() {
        log.debug("Нажата кнопка 'Редактор записей'");
        try {
            clinicFrame.setVisible(false);
            if (clinicFrame != null) {
                clinicFrame.dispose();
            }
            log.debug("Создан объект класса AppointmentForm");
            new Appointment_form().show_apps();
        } catch (SQLException | ParseException ex) {
            log.warn("Ошибка при открытии редактора записей ", ex);
            throw new RuntimeException(ex);
        }
    }

    private void patientsButtonAction() {
        log.debug("Нажата кнопка 'Показать пациентов'");
        clinicFrame.setVisible(false);
        if (clinicFrame != null) {
            clinicFrame.dispose();
        }
        log.debug("Создан объект класса Patient");
        Patient.show_patients();
    }

    private void depsButtonAction() {
        log.debug("Нажата кнопка 'Врачи и отделения'");
        if (clinicFrame != null) {
            clinicFrame.dispose();
        }
        log.debug("Создан объект класса DoctorsForm");
        Doctors_form form = new Doctors_form();
        form.show_form();
    }

    private void paperButtonAction() {
        log.debug("Нажата кнопка 'Печать справки'");
        if (clinicFrame != null) {
            clinicFrame.dispose();
        }
        log.debug("Создан объект класса PaperForm");
        Paper_form form = new Paper_form();
        try {
            form.show_paper();
        } catch (ParseException ex) {
            throw new RuntimeException(ex);
        }
    }

    public void show_apps() throws SQLException, ParseException {
        log.info("Отображение экранной формы редактора записей");
        clinicFrame = new JFrame("Записи");
        clinicFrame.setSize(700, 400);
        clinicFrame.setLocationRelativeTo(null);
        clinicFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        back = createButton("Назад", e -> backButtonAction());
        save = createButtonWithImage("C:\\Users\\pipop\\IdeaProjects\\kursach\\src\\main\\java\\img\\save.png", e -> saveAction());
        add = createButtonWithImage("C:\\Users\\pipop\\IdeaProjects\\kursach\\src\\main\\java\\img\\add.png", e -> addAction());
        delete = createButtonWithImage("C:\\Users\\pipop\\IdeaProjects\\kursach\\src\\main\\java\\img\\delete.png", e -> deleteAction());
        update = createButtonWithImage("C:\\Users\\pipop\\IdeaProjects\\kursach\\src\\main\\java\\img\\update.png", e -> updateAction());

        createToolBar();

        clinicFrame.setLayout(new BorderLayout());
        clinicFrame.add(toolBar, BorderLayout.NORTH);

        String[] columns = {"Номер", "Дата", "Время", "Пациент", "Врач"};
        model = new DefaultTableModel(columns, 0);
        appointments = new JTable(model);
        JComboBox cbPat = Patient.make_combo_box();
        appointments.getColumnModel().getColumn(3).setCellEditor(new AppComboBoxEditor(cbPat));
        JComboBox cbDoc = Doctor.make_combo_box();
        appointments.getColumnModel().getColumn(4).setCellEditor(new AppComboBoxEditor(cbDoc));
        addListeners(model);

        Appointment.fill_table(model);

        MaskFormatter maskFormatterDate = new MaskFormatter("####-##-##");
        appointments.getColumnModel().getColumn(1).setCellEditor(createCellEditorWithValidation(maskFormatterDate));

        MaskFormatter maskFormatterTime = new MaskFormatter("##:## - ##:##");
        appointments.getColumnModel().getColumn(2).setCellEditor(createCellEditorWithValidation(maskFormatterTime));

        JScrollPane scroll = new JScrollPane(appointments);
        clinicFrame.add(scroll, BorderLayout.CENTER);

        JPanel backPanel = new JPanel();
        backPanel.add(back);
        clinicFrame.add(backPanel, BorderLayout.SOUTH);
        clinicFrame.setVisible(true);
    }

    private void createToolBar() {
        toolBar = new JToolBar("Панель инструментов");
        toolBar.add(save);
        toolBar.add(add);
        toolBar.add(delete);
        toolBar.add(update);
    }

    private DefaultCellEditor createCellEditorWithValidation(MaskFormatter maskFormatter) {
        JFormattedTextField formattedTextField = new JFormattedTextField(maskFormatter);

        formattedTextField.setInputVerifier(new InputVerifier() {
            @Override
            public boolean verify(JComponent input) {
                JFormattedTextField textField = (JFormattedTextField) input;
                return textField.isEditValid();
            }
        });

        return new DefaultCellEditor(formattedTextField);
    }

    private void addAction() {
        log.debug("Нажата кнопка 'Добавить запись'");
        String[] fields = {"", "", "", "", ""};
        model.addRow(fields);
    }

    private void backButtonAction() {
        log.debug("Нажата кнопка 'Назад'");
        if (clinicFrame != null) {
            clinicFrame.dispose();
        }
        show_start();
    }

    private void saveAction() {
        try {
            log.debug("Нажата кнопка 'Сохранить'");
            Appointment.save_from_table(model);
            JOptionPane.showMessageDialog(clinicFrame, "Сохранено");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(clinicFrame, "Ошибка сохранения.\nПроверьте правильность введенных данных");
            log.warn("Ошибка при сохранении записи", ex);
        }
    }

    private void updateAction() {
        model.setRowCount(0);
        try {
            log.debug("Нажата кнопка 'Обновить'");
            Appointment.fill_table(model);
            JOptionPane.showMessageDialog(clinicFrame, "Информация обновлена");
        } catch (Exception ex) {
            log.warn("Ошибка при обновлении", ex);
        }
    }

    private void deleteAction() {
        log.debug("Нажата кнопка 'Удалить'");
        boolean flag = Are_You_Sure.showMessage();
        if (flag) {
            Appointment.delete_one_app(appointments, model);
            JOptionPane.showMessageDialog(clinicFrame, "Запись удалена");
        }
    }

    private void addListeners(DefaultTableModel model) {
        save.addActionListener(e -> saveAction());
        add.addActionListener(e -> addAction());
        delete.addActionListener(e -> deleteAction());
        update.addActionListener(e -> updateAction());

        appointments.getModel().addTableModelListener(e -> {
            if (e.getType() == TableModelEvent.UPDATE) {
                log.debug("Начато изменение записи в бд");
                int selectedRow = appointments.getSelectedRow();
                if (selectedRow != -1) {
                    String[] editedRow = new String[model.getColumnCount()];
                    for (int i = 0; i < model.getColumnCount(); i++) {
                        editedRow[i] = (String) appointments.getValueAt(selectedRow, i);
                    }

                    try {
                        if (!Objects.equals(editedRow[0], "")) {
                            Appointment.save_after_edit(editedRow, clinicFrame);
                        }

                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                }
            }
        });
    }

    public class AppComboBoxEditor extends DefaultCellEditor {
        public AppComboBoxEditor(JComboBox cb) {
            super(cb);
        }
    }

}
