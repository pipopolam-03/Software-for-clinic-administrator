package org.example;

import javax.persistence.*;
import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.ParseException;
import java.util.List;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

@Entity
@Table(name = "schedule")
public class Schedule {
    private static final Logger log = Logger.getLogger(Schedule.class.getName());
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    public int getID() {
        return id;
    }

    public void setID(int id) {
        this.id = id;
    }

    private String monday, tuesday, wednesday, thursday, friday, saturday, sunday;

    public String getMonday() {
        return monday;
    }

    public void setMonday(String monday) {
        this.monday = monday;
    }

    public String getTuesday() {
        return tuesday;
    }

    public void setTuesday(String tuesday) {
        this.tuesday = tuesday;
    }

    public String getWednesday() {
        return wednesday;
    }

    public void setWednesday(String wednesday) {
        this.wednesday = wednesday;
    }

    public String getThursday() {
        return thursday;
    }

    public void setThursday(String thursday) {
        this.thursday = thursday;
    }

    public String getFriday() {
        return friday;
    }

    public void setFriday(String friday) {
        this.friday = friday;
    }

    public String getSaturday() {
        return saturday;
    }

    public void setSaturday(String saturday) {
        this.saturday = saturday;
    }

    public String getSunday() {
        return sunday;
    }

    public void setSunday(String sunday) {
        this.sunday = sunday;
    }

    public void setSch(int id)
    {
        log.debug("Создан объект класса Schedule");
        this.setID(id);

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC", "root", "pipopolam")) {
            String sqlQuery = "SELECT monday, tuesday, wednesday, thursday, friday, saturday, sunday FROM schedule WHERE id = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setInt(1, id);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        this.setMonday(resultSet.getString("monday"));
                        this.setTuesday(resultSet.getString("tuesday"));
                        this.setWednesday(resultSet.getString("wednesday"));
                        this.setThursday(resultSet.getString("thursday"));
                        this.setFriday(resultSet.getString("friday"));
                        this.setSaturday(resultSet.getString("saturday"));
                        this.setSunday(resultSet.getString("sunday"));
                    }
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


    public static Schedule show_doctor_schedule(Doctor doctor) throws SQLException {
        log.debug("Начато получение расписания врача");
        Schedule schedule = new Schedule();
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            // Запрос для получения doctor_schedule_id по ID доктора
            String doctorScheduleIdQuery = "SELECT doctor_schedule_id FROM doctors WHERE d_id = ?";

            try (PreparedStatement doctorScheduleIdStatement = connection.prepareStatement(doctorScheduleIdQuery)) {
                doctorScheduleIdStatement.setInt(1, doctor.getID());

                try (ResultSet doctorScheduleIdResultSet = doctorScheduleIdStatement.executeQuery()) {
                    if (doctorScheduleIdResultSet.next()) {
                        int doctorScheduleId = doctorScheduleIdResultSet.getInt("doctor_schedule_id");

                        String scheduleQuery = "SELECT * FROM schedule WHERE id = ?";

                        try (PreparedStatement scheduleStatement = connection.prepareStatement(scheduleQuery)) {
                            scheduleStatement.setInt(1, doctorScheduleId);

                            try (ResultSet resultSet = scheduleStatement.executeQuery()) {
                                if (resultSet.next()) {
                                    schedule.setID(resultSet.getInt("id"));
                                    schedule.setMonday(resultSet.getString("monday"));
                                    schedule.setTuesday(resultSet.getString("tuesday"));
                                    schedule.setWednesday(resultSet.getString("wednesday"));
                                    schedule.setThursday(resultSet.getString("thursday"));
                                    schedule.setFriday(resultSet.getString("friday"));
                                    schedule.setSaturday(resultSet.getString("saturday"));
                                    schedule.setSunday(resultSet.getString("sunday"));
                                }
                            }
                        }
                    }
                }
            }
        }
        log.debug("Успешно выполнено получение расписания врача");
        return schedule;
    }


    void showSchedules(Doctor selectedDoctor) throws SQLException {
        log.info("Отображение расписания");
        JFrame booklist = new JFrame(selectedDoctor.getPerson().getFullname());
        booklist.setSize(400, 100);
        booklist.setLocationRelativeTo(null);
        booklist.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());


        if (selectedDoctor != null) {
            Schedule schedule = Schedule.show_doctor_schedule(selectedDoctor);

            String[] columnNames = {"ID", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"};
            Object[][] data = {};
            DefaultTableModel model = new DefaultTableModel(data, columnNames) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return column != 0;
                }
            };
            JTable scheduleTable = new JTable(model);
            for (int i = 1; i < model.getColumnCount(); i++) {
                TableColumn column = scheduleTable.getColumnModel().getColumn(i);
                if (i != 0) {  // Пропустите первую колонку (ID)
                    column.setCellEditor(new TimeCellEditor());
                }
            }
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            panel.add(new JScrollPane(scheduleTable), BorderLayout.CENTER);


            if (schedule != null) {

                String monday = schedule.getMonday();
                String tuesday = schedule.getTuesday();
                String wednesday = schedule.getWednesday();
                String thursday = schedule.getThursday();
                String friday = schedule.getFriday();
                String saturday = schedule.getSaturday();
                String sunday = schedule.getSunday();

                String[] fields = {String.valueOf(selectedDoctor.getSchedule().id), monday, tuesday, wednesday, thursday, friday, saturday, sunday};
                model.addRow(fields);
                contentPanel.add(panel, BorderLayout.CENTER);
                booklist.add(contentPanel);
                contentPanel.revalidate();
                contentPanel.repaint();
                booklist.setVisible(true);
                EnterListener(model, scheduleTable, booklist);
            } else {
                JOptionPane.showMessageDialog(booklist, "Расписание для выбранного врача не найдено.");
            }
        } else {
            JOptionPane.showMessageDialog(booklist, "Выберите врача из списка.");
        }

    }

    public class TimeCellEditor extends DefaultCellEditor {
        public TimeCellEditor() {
            super(new JFormattedTextField(createFormatter("##:##")));
        }

        private static MaskFormatter createFormatter(String s) {
            MaskFormatter formatter = null;
            try {
                formatter = new MaskFormatter(s);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            return formatter;
        }
    }

    public void EnterListener(DefaultTableModel model, JTable scheduleTable, JFrame booklist) {
        model.addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                if (e.getType() == TableModelEvent.UPDATE) {
                    log.debug("Начато изменение записи в бд");
                    int selectedRow = scheduleTable.getSelectedRow();
                    if (selectedRow != -1) {
                        String[] editedRow = new String[model.getColumnCount()];
                        for (int i = 0; i < model.getColumnCount(); i++) {
                            Object cellValue = scheduleTable.getValueAt(selectedRow, i);

                            if (cellValue == null || cellValue.toString().trim().isEmpty()) {
                                editedRow[i] = null;
                            } else {
                                if (Objects.equals(cellValue.toString(), "  :  ")) {
                                    editedRow[i] = null;
                                } else {
                                    editedRow[i] = cellValue.toString();;
                                }
                            }
                        }

                        try {
                            Schedule.save_after_edit(editedRow, booklist);
                        } catch (SQLException ex) {
                            throw new RuntimeException(ex);
                        }
                    }
                }
            }
        });
    }


    public static void save_after_edit(String[] row, JFrame booklist) throws SQLException {
        int sch_id = Integer.parseInt(row[0]);
        Schedule sch = new Schedule();
        sch.setSch(sch_id);
        sch.setMonday(row[1]);
        sch.setTuesday(row[2]);
        sch.setWednesday(row[3]);
        sch.setThursday(row[4]);
        sch.setFriday(row[5]);
        sch.setSaturday(row[6]);
        sch.setSunday(row[7]);


        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            String updateQuery = "UPDATE schedule SET monday=?, tuesday=?, wednesday=?, thursday=?, friday=?, saturday=?, sunday=? WHERE id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
                preparedStatement.setString(1, sch.getMonday());
                preparedStatement.setString(2, sch.getTuesday());
                preparedStatement.setString(3, sch.getWednesday());
                preparedStatement.setString(4, sch.getThursday());
                preparedStatement.setString(5, sch.getFriday());
                preparedStatement.setString(6, sch.getSaturday());
                preparedStatement.setString(7, sch.getSunday());
                preparedStatement.setInt(8, sch_id);

                int rowsUpdated = preparedStatement.executeUpdate();

                if (rowsUpdated > 0) {
                    log.debug("Запись успешно обновлена");;
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(booklist, "Ошибка. Проверьте правильность введенных данных");
            log.warn("Ошибка обновления записи", e);
            e.printStackTrace();
        }
    }



}