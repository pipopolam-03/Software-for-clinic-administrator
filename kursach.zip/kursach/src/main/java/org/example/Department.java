package org.example;

import javax.persistence.*;
import javax.swing.*;
import java.sql.*;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

@Entity
@Table(name = "departments")
public class Department {
    private static final Logger log = Logger.getLogger(Department.class.getName());
    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer department_id;

    public int getID() { return department_id; }
    public void setID(int department_id) { this.department_id = department_id; }

    @Column(name="department_name")
    private String department_name;
    public String getName() { return department_name; }
    public void setName(String department_name) { this.department_name = department_name; }

    public void setDep(int id)
    {
        log.debug("Создан объект класса Department");
        this.setID(id);

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC", "root", "pipopolam")) {
            String sqlQuery = "SELECT department_name FROM departments WHERE id = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setInt(1, id);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        this.setName(resultSet.getString("department_name"));

                    }
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public static int getIdByName(String dep_name) {
        int id = -1;
        log.debug("Начато получение ID отделения по названию");
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC", "root", "pipopolam")) {

            String sqlQuery = "SELECT id FROM departments WHERE department_name = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {

                preparedStatement.setString(1, dep_name);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        id = resultSet.getInt("id");
                    }
                }
                log.debug("Успешно выполнено получение ID отделения по названию");
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            log.warn("Ошибка получения ID отделения по названию", e);
            e.printStackTrace();
        }

        return id;
    }

    static JComboBox make_combo_box()
    {
        log.debug("Начата выгрузка названий отделений");
        String[] departments = {};
        JComboBox departmentComboBox = new JComboBox<>(departments);
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            Statement statement = connection.createStatement();
            String sqlQuery = "SELECT department_name FROM departments ";

            ResultSet resultSet = statement.executeQuery(sqlQuery);

            while (resultSet.next()) {
                String department_name = resultSet.getString(1);

                String field = department_name;
                departmentComboBox.addItem(field);
            }
            departmentComboBox.addItem("Все");
            log.debug("Успешно завершена выгрузка названий отделений");
        } catch (SQLException e) {
            log.warn("Ошибка выгрузки названий отделений", e);
            e.printStackTrace();
        }

        return departmentComboBox;
    }

}
