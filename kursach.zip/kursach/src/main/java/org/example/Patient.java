package org.example;

import javax.persistence.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import static org.example.Disease.showDiseases;

@Entity
@Table(name = "Patients")
public class Patient {
    private static final Logger log = Logger.getLogger(Patient.class.getName());
    @Id
    @Column(name="p_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer p_id;

    public int getID() { return p_id; }
    public void setID(int p_id) { this.p_id = p_id; }

    private String district, comments;

    @Column(name="patient_district")
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }


    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "name", column = @Column(name = "p_name")),
            @AttributeOverride(name = "last_name", column = @Column(name = "p_last_name")),
            @AttributeOverride(name = "surname", column = @Column(name = "p_surname")),
            @AttributeOverride(name = "sex", column = @Column(name = "patient_sex")),
            @AttributeOverride(name = "age", column = @Column(name = "patient_age"))
    })

    private Person person;
    public Person getPerson() { return person;}
    public void setPerson(Person person) {this.person = person;}

    @ManyToMany
    @JoinColumn(name = "patient_diseases_id")

    private List<Disease> diseases;
    public List<Disease> getDiseases() {return diseases;}
    public void setDiseases(List<Disease> diseases) {this.diseases = diseases;}

    public void setPatient(int id)
    {
        log.debug("Созлан объект класса Patient");
        this.setID(id);

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC", "root", "pipopolam")) {
            String sqlQuery = "SELECT p_name, p_surname, p_last_name, " +
                    "patient_sex, patient_age, patient_district " +
                    "FROM patients WHERE p_id = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setInt(1, id);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        this.setPerson(new Person());
                        this.person.setName(resultSet.getString("p_name"));
                        this.person.setLastName(resultSet.getString("p_last_name"));
                        this.person.setSurame(resultSet.getString("p_surname"));
                        this.person.setFullname();
                        this.person.setSex(resultSet.getString("patient_sex"));
                        this.person.setAge(resultSet.getInt("patient_age"));
                        this.setDistrict(resultSet.getString("patient_district"));
                    }
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }

    public static String getNameById(int id) {
        log.debug("Начато получение имени пациента по ID");
        String patientName = null;
        String patientSurname = null;
        String patientLastName = null;

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC", "root", "pipopolam")) {
            String sqlQuery = "SELECT p_name, p_last_name, p_surname FROM patients WHERE p_id = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setInt(1, id);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        patientName = resultSet.getString("p_name");
                        patientLastName = resultSet.getString("p_last_name");
                        patientSurname = resultSet.getString("p_surname");
                    }
                }
                log.debug("Успешно завершено получение имени пациента по ID");
            } catch (SQLException e) {
                log.warn("Ошибка получения имени пациента по ID", e);
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return patientName + " " + patientLastName + " " + patientSurname;
    }

    public static int getIdByName(String patient_fullname) {
        log.debug("Начато получение ID пациента по имени");
        int patient_id = -1;

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC", "root", "pipopolam")) {
            String[] nameComponents = patient_fullname.split("\\s+");

            if (nameComponents.length >= 3) {
                String patient_name = nameComponents[0];
                String patient_last_name = nameComponents[1];
                String patient_surname = nameComponents[2];

                String sqlQuery = "SELECT p_id FROM patients WHERE p_name = ? AND p_last_name = ? AND p_surname = ?";

                try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                    preparedStatement.setString(1, patient_name);
                    preparedStatement.setString(2, patient_last_name);
                    preparedStatement.setString(3, patient_surname);

                    try (ResultSet resultSet = preparedStatement.executeQuery()) {
                        if (resultSet.next()) {
                            patient_id = resultSet.getInt("p_id");
                        }
                    }

                    log.debug("Успешно завершено получение ID пациента по имени");

                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            } else {
                log.debug("Ошибка получения ID пациента по имени");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return patient_id;
    }

        public String form_diseases()
        {
            log.info("Отображение таблицы болезней");
            String diseases="";
            try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
                String sqlQuery = "SELECT disease_id FROM patient_disease WHERE patient_id = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setInt(1, this.getID());

            ResultSet resultSet = preparedStatement.executeQuery();
            int disease_id;
            Disease disease = new Disease();

            while (resultSet.next()) {
                disease_id = resultSet.getInt(1);
                disease.setDisease(disease_id);
                diseases += disease.getName() + ", ";
            }
                diseases = diseases.substring(0, diseases.length() - 2);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return diseases;

    }

    public static void show_patients() {
        log.debug("Отображение окна пациентов");
        JFrame booklist = new JFrame("Пациенты");
        booklist.setSize(600, 300);
        booklist.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());
        booklist.setLocationRelativeTo(null);

        log.debug("Начата выгрузка пациентов");
        Patient patient = new Patient();
        JTable patients_table = new JTable();
        String[] columns = {"id", "ФИО", "Район"};
        Object[][] data = {};
        DefaultTableModel model = new DefaultTableModel(data, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0;
            }
        };
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            Statement statement = connection.createStatement();
            String sqlQuery = "SELECT p_id FROM patients";
            ResultSet resultSet = statement.executeQuery(sqlQuery);

            while (resultSet.next()) {
                int patient_id = resultSet.getInt(1);
                patient.setPatient(patient_id);
                fill_table(model);
            }
            log.debug("Успешно завершена выгрузка пациентов");
        } catch (SQLException e) {
            log.warn("Ошибка выгрузки пациентов", e);
            e.printStackTrace();
        }

        JButton showDiseasesButton = new JButton("Показать болезни");
        JButton backButton = new JButton("Назад");
        JButton save = new JButton("Сохранить");
        JButton update = new JButton("Обновить");
        JButton add = new JButton("Добавить");
        JButton delete = new JButton("Удалить");


        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажата кнопка 'Назад'");
                if (booklist != null) {
                    booklist.dispose();
                }
                Appointment_form form = new Appointment_form();
                form.show_start();
            }
        });

        update.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    fill_table(model);
                    JOptionPane.showMessageDialog(booklist, "Инфромация обновлена");
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        delete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                boolean flag = Are_You_Sure.showMessage();
                if (flag) {
                    log.debug("Нажата кнопка 'Удалить'");
                    int row = patients_table.getSelectedRow();
                    int patient_id = Integer.parseInt((String) model.getValueAt(row, 0));
                    try {
                        Patient.delete_patient(patient_id);
                        model.removeRow(row);
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                    JOptionPane.showMessageDialog(booklist, "Запись удалена");
                }
            }
        });

        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Patient.show_add_form(model);
            }
        });

        showDiseasesButton.addActionListener(new ActionListener() {
            int patient_id;
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажата кнопка 'Показать диагнозы'");
                if (booklist != null) {
                    booklist.dispose();
                }
                int patient_id = patients_table.getSelectedRow();
                patient.setPatient(patient_id);
                Disease disease =  new Disease();
                try {
                    disease.showPatientDiseases(patient);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        save.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            log.debug("Нажата кнопка 'Сохранить'");
            Patient curr_patient = new Patient();
            int rows = model.getRowCount();
            for (int row = 0; row < rows; row++) {
                    curr_patient.setPatient(Integer.parseInt((String) model.getValueAt(row, 0)));
                    String p_fullname = (String) model.getValueAt(row, 1);
                    String[] name = p_fullname.split("\\s+");
                    if (name.length == 3)
                    {
                        curr_patient.getPerson().setName(name[0]);
                        curr_patient.getPerson().setLastName(name[1]);
                        curr_patient.getPerson().setSurame(name[2]);
                    }
                    else {
                        curr_patient.getPerson().setName(name[0]);
                        curr_patient.getPerson().setLastName("");
                        curr_patient.getPerson().setSurame(name[1]);
                    }

                    curr_patient.setDistrict((String) model.getValueAt(row, 2));
                    try {
                        Patient.export_to_db(curr_patient);
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(booklist, "Ошибка сохранения");
                        throw new RuntimeException(ex);
                    }
                }
                JOptionPane.showMessageDialog(booklist, "Инфромация сохранена");

            }
        });

        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        patients_table.setModel(model);
        panel.add(patients_table);
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.add(backButton);
        bottomPanel.add(showDiseasesButton);
        bottomPanel.add(save);
        bottomPanel.add(update);
        bottomPanel.add(add);
        bottomPanel.add(delete);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        contentPanel.add(panel, BorderLayout.CENTER);
        JScrollPane scrollPane = new JScrollPane(patients_table);
        panel.add(scrollPane);
        booklist.add(panel);
        booklist.setVisible(true);

    }

    public static void show_add_form(DefaultTableModel model) {
        log.info("Открыта форма добавления нового пациента");
        JFrame booklist = new JFrame("Добавить пациента");
        booklist.setSize(400, 400);
        booklist.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        booklist.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(9, 2, 10, 10));

        panel.add(new JLabel("Фамилия:"));
        JTextField lastNameField = new JTextField();
        panel.add(lastNameField);

        panel.add(new JLabel("Имя:"));
        JTextField firstNameField = new JTextField();
        panel.add(firstNameField);

        panel.add(new JLabel("Отчество:"));
        JTextField middleNameField = new JTextField();
        panel.add(middleNameField);

        panel.add(new JLabel("Пол:"));
        JComboBox<String> genderComboBox = new JComboBox<>(new String[]{"Муж", "Жен"});
        panel.add(genderComboBox);

        panel.add(new JLabel("Возраст:"));
        Doctors_form.DigitOnlyTextField ageField = new Doctors_form.DigitOnlyTextField();
        panel.add(ageField);

        panel.add(new JLabel("Район:"));
        JTextField districtField = new JTextField();
        panel.add(districtField);

        JButton addButton = new JButton("Сохранить");
        panel.add(addButton);

        booklist.add(panel);
        booklist.setVisible(true);

        Patient patient = new Patient();
        patient.setPerson(new Person());
        addButton.addActionListener(e -> {
            if (isAllFieldsFilled(lastNameField, firstNameField, ageField, districtField)) {
                try {
                    log.debug("Начато добавление нового пациента");
                    patient.getPerson().setSurame(lastNameField.getText());
                    patient.getPerson().setName(firstNameField.getText());
                    patient.getPerson().setLastName(middleNameField.getText());
                    patient.getPerson().setSex((String) genderComboBox.getSelectedItem());
                    patient.getPerson().setFullname();
                    patient.getPerson().setAge(Integer.valueOf(ageField.getText()));
                    patient.setDistrict(districtField.getText());
                    try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
                        String insertQuery = "INSERT INTO patients (p_name, p_last_name, p_surname, patient_sex, patient_age, patient_district) VALUES (?, ?, ?, ?, ?, ?)";

                        try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
                            preparedStatement.setString(1, patient.getPerson().getName());
                            preparedStatement.setString(2, patient.getPerson().getLastName());
                            preparedStatement.setString(3, patient.getPerson().getSurame());
                            preparedStatement.setString(4, patient.getPerson().getSex());
                            preparedStatement.setInt(5, patient.getPerson().getAge());
                            preparedStatement.setString(6, patient.getDistrict());
                            preparedStatement.executeUpdate();

                            log.debug("Успешно завершен экспорт записей больничных листов в базу данных");

                        } catch (SQLException ex) {
                            log.warn("Ошибка экспорта записей больничных листов в базу данных", ex);
                            ex.printStackTrace();
                            throw new RuntimeException("Error during INSERT operation", ex);
                        }
                        patient.setID(getIdByName(patient.getPerson().getFullname()));
                        String[] fields = {String.valueOf(patient.getID()), patient.getPerson().getFullname(), patient.getDistrict()};
                        model.addRow(fields);
                        booklist.dispose();
                        log.debug("Успешно завершено добавление нового врача");
                    }

                    } catch (Exception ex) {
                        log.warn("Ошибка добавления нового врача", ex);
                        ex.printStackTrace();
                    }
            }
            else
            {
                    JOptionPane.showMessageDialog(booklist, "Заполните все обязательные поля", "Предупреждение", JOptionPane.WARNING_MESSAGE);
            }
        });
    }
    private static boolean isAllFieldsFilled(JTextField lastName, JTextField firstName, Doctors_form.DigitOnlyTextField age, JTextField district) {
        return !lastName.getText().isEmpty() && !firstName.getText().isEmpty() && !age.getText().isEmpty() && !district.getText().isEmpty();
    }

    public static void export_to_db(Patient patient) throws SQLException {
        log.debug("Начат экспорт записей больничных листов в базу данных");
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            String insertQuery;
            insertQuery = "UPDATE patients SET p_name = ?, p_last_name = ?, p_surname = ?, patient_sex = ?, patient_age = ?, patient_district = ? WHERE p_id = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
                preparedStatement.setString(1, patient.getPerson().getName());
                preparedStatement.setString(2, patient.getPerson().getLastName());
                preparedStatement.setString(3, patient.getPerson().getSurame());
                preparedStatement.setString(4, patient.getPerson().getSex());
                preparedStatement.setInt(5, patient.getPerson().getAge());
                preparedStatement.setString(6, patient.getDistrict());
                preparedStatement.setInt(7, patient.getID());
                preparedStatement.executeUpdate();

                log.debug("Успешно завершен экспорт записей больничных листов в базу данных");

            } catch (SQLException ex) {
                log.warn("Ошибка экспорта записей больничных листов в базу данных", ex);
                ex.printStackTrace();
                throw new RuntimeException("Error during INSERT operation", ex);
            }
        }

    }

    public static void fill_table(DefaultTableModel model) throws SQLException {
        log.debug("Начато заполнение таблицы");
        int rows = model.getRowCount();
        for (int i = 0; i < rows; i++) {
            model.removeRow(0);
        }

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            Statement statement = connection.createStatement();
            String sqlQuery = "SELECT p_id FROM patients ";
            ResultSet resultSet = statement.executeQuery(sqlQuery);

            while (resultSet.next()) {
                Patient patient = new Patient();
                int p_id = resultSet.getInt(1);
                patient.setPatient(p_id);
                String[] fields = {String.valueOf(p_id), patient.person.getFullname(), patient.district};
                model.addRow(fields);
            }

            log.debug("Таблица успешно заполнена");

        } catch (SQLException e) {
            log.warn("Ошибка при заполнении таблицы", e);
            e.printStackTrace();
        }
    }

    public static void delete_patient(int patient_id) throws SQLException {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            connection.setAutoCommit(false);
            try {

                String deleteAppointmentsQuery = "DELETE FROM appointments WHERE appointment_patient_id = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(deleteAppointmentsQuery)) {
                    preparedStatement.setInt(1, patient_id);
                    preparedStatement.executeUpdate();
                }

                String deletePapersQuery = "DELETE FROM papers WHERE paper_patient_id = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(deletePapersQuery)) {
                    preparedStatement.setInt(1, patient_id);
                    preparedStatement.executeUpdate();
                }

                String deleteSchedulesQuery = "DELETE FROM patient_disease WHERE patient_id = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(deleteSchedulesQuery)) {
                    preparedStatement.setInt(1, patient_id);
                    preparedStatement.executeUpdate();
                }

                String deleteDoctorQuery = "DELETE FROM patients WHERE p_id = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(deleteDoctorQuery)) {
                    preparedStatement.setInt(1, patient_id);
                    preparedStatement.executeUpdate();
                }


                connection.commit();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    static JComboBox make_combo_box()
    {
        log.debug("Начата выгрузка пациентов");
        String[] departments = {};
        JComboBox cb = new JComboBox<>(departments);
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            Statement statement = connection.createStatement();
            String sqlQuery = "SELECT p_name, p_last_name, p_surname FROM patients ";

            ResultSet resultSet = statement.executeQuery(sqlQuery);

            while (resultSet.next()) {
                String p_fullname = resultSet.getString(1) + " " + resultSet.getString(2) + " " + resultSet.getString(3);
                cb.addItem(p_fullname);
            }
            log.debug("Успешно завершена выгрузка пациентов");
        } catch (SQLException e) {
            log.warn("Ошибка выгрузки пациентов", e);
            e.printStackTrace();
        }

        return cb;
    }


}
