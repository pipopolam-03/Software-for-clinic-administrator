package org.example;

import javax.persistence.*;
import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.*;
import java.util.List;

import org.apache.log4j.Logger;

import static java.lang.Integer.parseInt;

/**
 * Класс, представляющий болезнь в системе.
 */
@Entity
@Table(name = "diseases")
public class Disease {
    private static final Logger log = Logger.getLogger(Disease.class.getName());
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private static int cnt_after_import;
    private static int cnt_before_export;
    private int disease_id;

    /**
     * Получить идентификатор болезни.
     *
     * @return Идентификатор болезни.
     */
    public int getID() {
        return disease_id;
    }

    /**
     * Установить идентификатор болезни.
     *
     * @param disease_id Идентификатор болезни.
     */
    public void setID(int disease_id) {
        this.disease_id = disease_id;
    }

    @Column(name = "disease_name")
    private String disease_name;

    /**
     * Получить название болезни.
     *
     * @return Название болезни.
     */
    public String getName() {
        return disease_name;
    }

    /**
     * Установить название болезни.
     *
     * @param disease_name Название болезни.
     */
    public void setName(String disease_name) {
        this.disease_name = disease_name;
    }

    @ManyToOne
    @JoinColumn(name = "disease_department_id")
    private Department department;

    /**
     * Получить отдел, связанный с болезнью.
     *
     * @return Объект отдела.
     */
    public Department getDepartment() {
        return department;
    }

    /**
     * Установить отдел, связанный с болезнью.
     *
     * @param department Объект отдела.
     */
    public void setDepartment(Department department) {
        this.department = department;
    }

    /**
     * Установить болезнь по её идентификатору.
     *
     * @param id Идентификатор болезни.
     */
    public void setDisease(int id) {
        log.debug("Создан объект класса Disease");
        this.setID(id);
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC", "root", "pipopolam")) {
            String sqlQuery = "SELECT disease_name, disease_department_id FROM diseases WHERE id = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setInt(1, id);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        Department dep = new Department();
                        this.setName(resultSet.getString("disease_name"));
                        dep.setDep(parseInt(resultSet.getString("disease_department_id")));
                        this.setDepartment(dep);
                    }
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Метод для получения id болезни по названию
     * @param diseaseName
     * @return
     */
    public static int getIdByName(String diseaseName) {
        int diseaseId = -1;
        log.debug("Начато получение ID болезни по названию");
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC", "root", "pipopolam")) {
            String sqlQuery = "SELECT id FROM diseases WHERE disease_name = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setString(1, diseaseName);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        diseaseId = resultSet.getInt("id");
                    }
                }

                log.debug("Успешно выполнено получение ID болезни по названию");
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            diseaseId = -1;
            log.warn("Ошибка получения ID болезни по названию", e);
            e.printStackTrace();
        }

        return diseaseId;
    }

    /**
     * Метод для отображения экрана редактирования болезней
     * @param dep_id
     */
    static void showDiseases(int dep_id) {
        log.info("Отображение редактора болезней");
        JFrame booklist = new JFrame("Болезни");
        booklist.setSize(500, 400);
        booklist.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        booklist.setLocationRelativeTo(null);

        String[] columnNames = {"ID", "Название", "Количество больных"};
        Object[][] data = {};
        DefaultTableModel model = new DefaultTableModel(data, columnNames) {
            public boolean isCellEditable(int row, int column) {
                return column == 1;
            }
        };
        JTable diseasesTable = new JTable(model);


        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(diseasesTable), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton backButton = new JButton("Назад");
        JButton add = new JButton("Добавить");
        JButton delete = new JButton("Удалить");
        JButton save = new JButton("Сохранить");
        JButton update = new JButton("Обновить");
        buttonPanel.add(backButton);
        buttonPanel.add(add);
        buttonPanel.add(save);
        buttonPanel.add(delete);
        buttonPanel.add(update);
        fill_table(model, dep_id);
        EnterListener(model, diseasesTable, booklist);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (booklist != null) {
                    booklist.dispose();
                }
                Doctors_form form = new Doctors_form();
                form.show_form();
            }
        });

        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажата кнопка 'Добавить болезнь'");
                if (dep_id != -1) {
                    model.addRow(new String[]{"", ""});
                }
                else {
                    JOptionPane.showMessageDialog(booklist, "Добавление возможно только в конкретное отделение");
                }

            }

        });


        update.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажата кнопка 'Обновить'");
                try {
                    fill_table(model, dep_id);
                    JOptionPane.showMessageDialog(booklist, "Информация обновлена");
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        save.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Disease disease = new Disease();
                log.debug("Нажата кнопка 'Сохранить'");
                try {
                    disease.export_to_db(model, dep_id);
                    JOptionPane.showMessageDialog(booklist, "Сохранено");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(booklist, "Ошибка сохранения.\nПроверьте правильность введенных данных");
                    ex.printStackTrace();
                }
            }
        });

        delete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажата кнопка 'Удалить'");
                boolean flag = Are_You_Sure.showMessage();
                if (flag) {
                    try {
                        int row = diseasesTable.getSelectedRow();

                        if (row != -1) {
                            String diseaseName = model.getValueAt(row, 1).toString();

                            int disease_id = Disease.getIdByName(diseaseName);

                            Disease.delete_disease(disease_id);

                            model.removeRow(row);

                            JOptionPane.showMessageDialog(booklist, "Болезнь и связанные записи удалены успешно");
                        }
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(booklist, "Ошибка удаления");
                        ex.printStackTrace();
                    }
                }
            }
        });


        booklist.add(panel);
        booklist.setVisible(true);



    }

    void showPatientDiseases(Patient patient) throws SQLException {
        log.info("Отображение редактора болезней");
        JFrame booklist = new JFrame("Болезни");
        booklist.setSize(500, 400);
        booklist.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        booklist.setLocationRelativeTo(null);

        String[] columnNames = {"ID", "Название"};
        Object[][] data = {};
        DefaultTableModel model = new DefaultTableModel(data, columnNames) {
            public boolean isCellEditable(int row, int column) {
                return column == 1;
            }
        };
        JTable diseasesTable = new JTable(model);
        JComboBox cb = make_combo_box();
        diseasesTable.getColumnModel().getColumn(1).setCellEditor(new DiseaseComboBoxEditor(cb));
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(diseasesTable), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton add = new JButton("Добавить");
        JButton delete = new JButton("Удалить");
        JButton save = new JButton("Сохранить");
        JButton update = new JButton("Обновить");
        JButton back = new JButton("Назад");
        buttonPanel.add(add);
        buttonPanel.add(save);
        buttonPanel.add(delete);
        buttonPanel.add(update);
        buttonPanel.add(back);
        EnterListener(model, diseasesTable, booklist);
        Disease.update_patient_diseases(model, patient);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажата кнопка 'Добавить болезнь'");
                model.addRow(new String[]{"", ""});
            }

        });

        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажата кнопка 'Назад'");
                booklist.dispose();
                Patient.show_patients();
            }

        });

        save.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Disease disease = new Disease();
                log.debug("Нажата кнопка 'Сохранить'");
                try {
                    disease.save_to_patient(patient.getID(), model);
                    JOptionPane.showMessageDialog(booklist, "Сохранено");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(booklist, "Ошибка сохранения.\nПроверьте правильность введенных данных");
                    ex.printStackTrace();
                }
            }
        });

        update.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажата кнопка 'Обновить'");
                try {
                    update_patient_diseases(model, patient);
                    JOptionPane.showMessageDialog(booklist, "Информация обновлена");
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        delete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажата кнопка 'Удалить'");
                boolean flag = Are_You_Sure.showMessage();
                if (flag) {
                    try {
                        int row = diseasesTable.getSelectedRow();

                        if (row != -1) {
                            String diseaseName = model.getValueAt(row, 1).toString();

                            int disease_id = Disease.getIdByName(diseaseName);

                            Disease.delete_from_patient(disease_id, patient.getID());

                            model.removeRow(row);

                            JOptionPane.showMessageDialog(booklist, "Болезнь у пациента удалена");
                        }
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(booklist, "Ошибка удаления");
                        ex.printStackTrace();
                    }
                }
            }
        });


        booklist.add(panel);
        booklist.setVisible(true);



    }


    static void update_patient_diseases(DefaultTableModel model, Patient patient) {
        log.debug("Начато заполнение таблицы болезней");
        int rows = model.getRowCount();
        for (int i = 0; i < rows; i++) {
            model.removeRow(0);
        }
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            String sqlQuery = "SELECT disease_id FROM patient_disease WHERE patient_id = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setInt(1, patient.getID()+1);
            ResultSet resultSet = preparedStatement.executeQuery();


            while (resultSet.next()) {
                Integer id = resultSet.getInt(1);
                Disease disease = new Disease();
                disease.setDisease(id);
                String[] fields = {String.valueOf(id), disease.getName()};
                model.addRow(fields);
            }
            log.debug("Заполнение таблицы болезней завершено успешно");
        } catch (SQLException e) {
            e.printStackTrace();
            log.warn("Ошибка при заполнении таблицы болезней", e);
        }
    }

    /**
     * Метод для подсчетв количества больных данным заболеванием
     * @param disease
     * @return
     */
    public static int count_diseases(Disease disease) {
        log.debug("Начат подсчет пациентов с текущей болезнью");
        int count = 0;
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            String sqlQuery = "SELECT patient_id FROM patient_disease WHERE disease_id = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setInt(1, disease.getID()); // Используйте метод getter, а не обращайтесь к полю напрямую

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        count++;
                    }
                }

                log.debug("Успешно выполнен подсчет пациентов с текущей болезнью");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            log.warn("Ошибка при подсчете пациентов с текущей болезнью", e);
        }

        return count;
    }


    /**
     * Слушатель для кнопки enter для вызова метода сохранения изменений
     * @param model
     * @param diseasesTable
     * @param booklist
     */
    public static void EnterListener(DefaultTableModel model, JTable diseasesTable, JFrame booklist)
    {
        model.addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                if (e.getType() == TableModelEvent.UPDATE) {
                    log.debug("Начато изменение записи в бд");
                    int selectedRow = diseasesTable.getSelectedRow();
                    if (selectedRow != -1) {
                        String[] editedRow = new String[model.getColumnCount()];
                        for (int i = 0; i < model.getColumnCount(); i++) {
                            editedRow[i] = (String) diseasesTable.getValueAt(selectedRow, i);
                        }

                        try {
                            if (!Objects.equals(editedRow[0], ""))
                            {
                                Disease.save_after_edit(editedRow, booklist);
                            }

                        } catch (SQLException ex) {
                            throw new RuntimeException(ex);
                        }
                    }
                }
            }
        });

    }

    /**
     * Метод для сохранения изменений после редактирования строки
     * @param row
     * @param booklist
     * @throws SQLException
     */
    public static void save_after_edit(String[] row, JFrame booklist) throws SQLException {
        int disease_id = -1;
        Disease disease = new Disease();
        disease_id = parseInt(row[0]);
        disease.setDisease(disease_id);
        disease.setName(row[1]);

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            String updateQuery = "UPDATE diseases SET disease_name=? WHERE id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
                preparedStatement.setString(1, disease.getName());
                preparedStatement.setInt(2, disease_id);

                int rowsUpdated = preparedStatement.executeUpdate();

                if (rowsUpdated > 0) {
                    log.debug("Запись успешно обновлена");;
                }
            }
        } catch (SQLException e) {
            log.warn("Ошибка обновления записи", e);
            JOptionPane.showMessageDialog(booklist, "Ошибка. Проверьте правильность введенных данных");

            e.printStackTrace();
        }
    }

    /**
     * Метод для экспорта в базу данных
     * @param model
     * @param dep_id
     * @throws SQLException
     */
    public static void export_to_db(DefaultTableModel model, int dep_id) throws SQLException {
        log.debug("Начат экспорт данных из таблицы болезней в базу данных");
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {

            String insertQuery = "INSERT INTO diseases (disease_name, disease_department_id) VALUES (?, ?)";

            try (PreparedStatement insertStatement = connection.prepareStatement(insertQuery)) {
                cnt_before_export = model.getRowCount();
                int rows = cnt_after_import;
                cnt_after_import = model.getRowCount();
                for (int row = rows; row < cnt_before_export; row++) {
                    String disease_name = model.getValueAt(row, 1).toString();
                    insertStatement.setString(1, disease_name);
                    insertStatement.setInt(2, dep_id);
                    insertStatement.executeUpdate();
                }

                log.debug("Успешно завершен экспорт данных из таблицы болезней в базу данных");
            } catch (SQLException ex) {
                ex.printStackTrace();
                log.warn("Ошибка экспорта данных из таблицы болезней в базу данных", ex);
                throw new RuntimeException(ex);
            }
        }
    }

    /**
     * Метод для удаления болезни
     * @param disease_id
     * @throws SQLException
     */
    public static void delete_disease(int disease_id) throws SQLException {
        log.debug("Удалена болезнь из таблицы");
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            connection.setAutoCommit(false);

            try {

                String deletePapersQuery = "DELETE FROM patient_disease WHERE disease_id = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(deletePapersQuery)) {
                    preparedStatement.setInt(1, disease_id);
                    preparedStatement.executeUpdate();
                }

                String deleteDoctorQuery = "DELETE FROM diseases WHERE id = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(deleteDoctorQuery)) {
                    preparedStatement.setInt(1, disease_id);
                    preparedStatement.executeUpdate();
                }

                connection.commit();
            } catch (SQLException e) {
                connection.rollback();
                e.printStackTrace();
                throw e;
            }
        }
    }

    public static void delete_from_patient(int disease_id, int patient_id) throws SQLException {
        log.debug("Удалена болезнь из пациента");
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            connection.setAutoCommit(false);

            try {

                String deletePapersQuery = "DELETE FROM patient_disease WHERE disease_id = ? AND patient_id = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(deletePapersQuery)) {
                    preparedStatement.setInt(1, disease_id);
                    preparedStatement.setInt(2, patient_id);
                    preparedStatement.executeUpdate();
                }

                connection.commit();
            } catch (SQLException e) {
                connection.rollback();
                e.printStackTrace();
                throw e;
            }
        }
    }

    public static void deleteRecordsForPatient(int patient_id) throws SQLException {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            connection.setAutoCommit(false);

            try {
                String deleteForPatientQuery = "DELETE FROM patient_disease WHERE patient_id = ?";
                try (PreparedStatement deleteStatement = connection.prepareStatement(deleteForPatientQuery)) {
                    deleteStatement.setInt(1, patient_id);
                    deleteStatement.executeUpdate();
                }

                connection.commit();
            } catch (SQLException e) {
                connection.rollback();
                e.printStackTrace();
                throw e;
            }
        }
    }


    public static void save_to_patient(int patient_id, DefaultTableModel model) throws SQLException {
        log.debug("Добавление болезней пациенту");
        List<Disease> diseases =  new ArrayList<>();
        int rows = model.getRowCount();
        for (int row = 0; row < rows; row++) {
            Disease disease = new Disease();
            int disease_id = Disease.getIdByName((String) model.getValueAt(row, 1));
            disease.setDisease(disease_id);
            diseases.add(disease);
        }

        try {
            deleteRecordsForPatient(patient_id);
            try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
                connection.setAutoCommit(false);

                try {
                    String insertPapersQuery = "INSERT INTO patient_disease (patient_id, disease_id) VALUES (?, ?)";
                    try (PreparedStatement insertStatement = connection.prepareStatement(insertPapersQuery)) {
                        for (Disease curr_disease : diseases) {
                            insertStatement.setInt(1, patient_id);
                            insertStatement.setInt(2, curr_disease.getID());
                            insertStatement.addBatch();
                        }
                        insertStatement.executeBatch();
                    }

                    connection.commit();
                } catch (SQLException e) {
                    connection.rollback();
                    e.printStackTrace();
                    throw e;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }



    static void fill_table(DefaultTableModel model, int dep_id) {
        int rows = model.getRowCount();
        for (int i = 0; i < rows; i++) {
            model.removeRow(0);
        }
        log.debug("Начато заполнение таблицы болезней");

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            String sqlQuery = "SELECT id, disease_name FROM diseases";

            if (dep_id != -1) {
                sqlQuery += " WHERE disease_department_id = ?";
            }

            PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);

            if (dep_id != -1) {
                preparedStatement.setInt(1, dep_id);
            }

            ResultSet resultSet = preparedStatement.executeQuery();


            while (resultSet.next()) {
                Integer id = resultSet.getInt(1);
                String disease_name = resultSet.getString(2);
                Disease disease = new Disease();
                disease.setDisease(id);
                String[] fields = {String.valueOf(id), disease_name, String.valueOf(count_diseases(disease))};
                model.addRow(fields);
            }
            cnt_after_import = model.getRowCount();
            log.debug("Заполнение таблицы болезней завершено успешно");
        } catch (SQLException e) {
            e.printStackTrace();
            log.warn("Ошибка при заполнении таблицы болезней", e);
        }
    }

    static JComboBox make_combo_box()
    {
        log.debug("Начата выгрузка болезней");
        String[] departments = {};
        JComboBox cb = new JComboBox<>(departments);
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            Statement statement = connection.createStatement();
            String sqlQuery = "SELECT disease_name FROM diseases ";

            ResultSet resultSet = statement.executeQuery(sqlQuery);

            while (resultSet.next()) {
                String disease_name = resultSet.getString(1);
                cb.addItem(disease_name);
            }
            log.debug("Успешно завершена выгрузка названий отделений");
        } catch (SQLException e) {
            log.warn("Ошибка выгрузки названий отделений", e);
            e.printStackTrace();
        }

        return cb;
    }

    public class DiseaseComboBoxEditor extends DefaultCellEditor {
        public DiseaseComboBoxEditor(JComboBox cb) {
            super(cb);
        }
    }


}

