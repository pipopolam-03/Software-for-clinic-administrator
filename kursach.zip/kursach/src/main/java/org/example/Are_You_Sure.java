package org.example;

import javax.swing.*;

public class Are_You_Sure {

    public static boolean showMessage() {
        int result = JOptionPane.showConfirmDialog(
                null,
                "Удалить запись? (необратимо)",
                "Подтверждение",
                JOptionPane.YES_NO_OPTION
        );

        return result == JOptionPane.YES_OPTION;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> showMessage());
    }
}
