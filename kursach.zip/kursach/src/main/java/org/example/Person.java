package org.example;

import javax.persistence.*;
import java.util.List;

@Embeddable
public class Person {
    private String name, last_name, surname, fullname, sex;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getLastName() { return last_name; }
    public void setLastName(String last_name) { this.last_name = last_name; }

    public String getSurame() { return surname; }
    public void setSurame(String surname) { this.surname = surname; }

    public String getFullname() { return fullname; }
    public void setFullname() { this.fullname = this.name + " " + this.last_name + " " + this.surname; }



    public String getSex() { return sex; }
    public void setSex(String sex) { this.sex = sex; }

    private Integer age;
    public Integer getAge() { return age; }
    public void setAge(Integer age) { this.age = age; }


}
