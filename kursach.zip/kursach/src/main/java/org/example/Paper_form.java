package org.example;

import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Objects;
import javax.swing.JTable;
import javax.swing.text.MaskFormatter;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Paper_form {
    private static final Logger log = Logger.getLogger(Paper_form.class.getName());
    private static int cnt_after_import;
    private static int cnt_before_export;
    private Paper paper = new Paper();
    private JFrame booklist;
    private JPanel panel;
    private JButton print, add, save, back, update, delete;
    private JLabel titleLabel;
    private DefaultTableModel model;
    private JTable info;

    /**
     * Метод, отображающий редактор справок
     */
    public void show_paper() throws ParseException {
        log.info("Отображение редактора больничных листов");
        booklist = new JFrame("Справка");
        booklist.setSize(800, 400);
        booklist.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        booklist.setLocationRelativeTo(null);
        print = new JButton("Напечатать справку");
        add = new JButton("Новый лист");
        save = new JButton("Сохранить изменения");
        update = new JButton("Обновить");
        back = new JButton("Назад");
        delete = new JButton("Удалить лист");

        panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        String[] columns = {"Номер записи", "Пациент", "Врач", "Дата открытия", "Дата закрытия"};
        Object[][] data = {};
        DefaultTableModel model = new DefaultTableModel(data, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0;
            }
        };
        Paper.import_from_db(model);
        cnt_after_import = model.getRowCount();
        JTable info = new JTable(model);
        MaskFormatter maskFormatterDate = new MaskFormatter("####-##-##");
        info.getColumnModel().getColumn(3).setCellEditor(createCellEditorWithValidation(maskFormatterDate));
        info.getColumnModel().getColumn(4).setCellEditor(createCellEditorWithValidation(maskFormatterDate));

        JComboBox cb_pat = Patient.make_combo_box();
        info.getColumnModel().getColumn(1).setCellEditor(new PapComboBoxEditor(cb_pat));
        JComboBox cb_doc = Doctor.make_combo_box();
        info.getColumnModel().getColumn(2).setCellEditor(new PapComboBoxEditor(cb_doc));

        titleLabel = new JLabel("Больничные листы", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(15, 0, 10, 0));

        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(new JScrollPane(info), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(print);
        PrintListener(info);

        buttonPanel.add(add);
        AddListener(model);

        buttonPanel.add(delete);
        DeleteListener(info, model);

        buttonPanel.add(save);
        SaveListener(model);

        buttonPanel.add(update);
        UpdateListener(model);

        buttonPanel.add(back);
        BackListener(booklist);


        EnterListener(model, info);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        booklist.setLayout(new BorderLayout());
        booklist.add(panel, BorderLayout.CENTER);

        booklist.setVisible(true);

        MaskFormatter maskFormatter_date = null;
        try {
            maskFormatter_date = new MaskFormatter("####-##-##");
        } catch (ParseException e) {
            e.printStackTrace();
        }

        JFormattedTextField formattedTextField = new JFormattedTextField(maskFormatter_date);
        DefaultCellEditor cellEditor = new DefaultCellEditor(formattedTextField);
        info.getColumnModel().getColumn(3).setCellEditor(cellEditor);
        info.getColumnModel().getColumn(4).setCellEditor(cellEditor);

    }

    /**
     * Слушатель для кнопки add, добавляет новую строку в таблицу
     */
    private void AddListener(DefaultTableModel model) {
        add.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажат кнопка 'Добавить лист'");
                try {
                    String[] fields = {"", "", "", "", ""};
                    model.addRow(fields);
                } catch (Exception ex) {
                }
            }
        });
    }

    private void UpdateListener(DefaultTableModel model) {
        update.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажат кнопка 'Обновить'");
                try {
                    model.setRowCount(0);
                    Paper.import_from_db(model);
                    JOptionPane.showMessageDialog(booklist, "Информация обновлена");
                } catch (Exception ex) {
                }
            }
        });
    }

    /**
     * Слушатель для кнопки enter, вызывает метод для сохранения изменений
     */
    public void EnterListener(DefaultTableModel model, JTable info)
    {
        model.addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                if (e.getType() == TableModelEvent.UPDATE) {
                    log.debug("Начато изменение записи в бд");
                    int selectedRow = info.getSelectedRow();
                    if (selectedRow != -1) {
                        String[] editedRow = new String[model.getColumnCount()];
                        for (int i = 0; i < model.getColumnCount(); i++) {
                            editedRow[i] = (String) info.getValueAt(selectedRow, i);
                        }

                        try {
                            if (!Objects.equals(editedRow[0], ""))
                            {
                                Paper.save_after_edit(editedRow, booklist);
                            }

                        } catch (SQLException ex) {
                            JOptionPane.showMessageDialog(booklist, "Ошибка. Проверьте правильность введенных данных");
                            log.warn("Ошибка обновления записи", ex);
                            throw new RuntimeException(ex);
                        }
                    }
                }
            }
        });

    }

    /**
     * Слушатель для кнопки back, возвращает к предыдущему окну
     */
    private void BackListener(JFrame booklist) {
        back.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажат кнопка 'Назад'");
                try {
                    booklist.dispose();
                    Appointment_form form = new Appointment_form();
                    form.show_start();
                } catch (Exception ex) {
                }
            }
        });
    }

    /**
     * Слушатель для кнопки print, вызывает метод для создания справки
     */
    private void PrintListener(JTable info) {
        print.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажат кнопка 'Печать справки'");
                try {
                    int selectedRow = info.getSelectedRow();
                    int paper_id = -1;
                    if (selectedRow != -1) {
                        Object value = info.getValueAt(selectedRow, 0);
                        paper_id = Integer.parseInt(value.toString());
                        paper.setPaper(paper_id);
                    }
                    Paper.fillJasperReport(paper);
                    JOptionPane.showMessageDialog(booklist, "Справка записана в файл 'output.pdf'");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(booklist, "Выберите, чью справку нужно напечатать");
                    throw new RuntimeException(ex);
                }
            }
        });
    }

    /**
     * Слушатель для кнопки delete, удаляет строку
     */
    private void DeleteListener(JTable info, DefaultTableModel model) {
        delete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажат кнопка 'Удалить лист'");
                boolean flag = Are_You_Sure.showMessage();
                if (flag) {
                    try {
                        int row = info.getSelectedRow();

                        if (row != -1) {

                            if (model.getValueAt(row, 0).toString() != "") {
                                int paper_id = Integer.parseInt(model.getValueAt(row, 0).toString());
                                Paper.delete_paper(paper_id);
                            }
                            model.removeRow(row);

                            JOptionPane.showMessageDialog(booklist, "Лист и связанные записи удалены успешно");
                        }

                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(booklist, "Ошибка удаления");
                        ex.printStackTrace();
                    }
                }
            }
        });
    }


    private DefaultCellEditor createCellEditorWithValidation(MaskFormatter maskFormatter) {
        JFormattedTextField formattedTextField = new JFormattedTextField(maskFormatter);

        formattedTextField.setInputVerifier(new InputVerifier() {
            @Override
            public boolean verify(JComponent input) {
                JFormattedTextField textField = (JFormattedTextField) input;
                return textField.isEditValid();
            }
        });

        return new DefaultCellEditor(formattedTextField);
    }

    /**
     * Слушатель для кнопки save, вызывает метод для сохранения изменений
     */
    private void SaveListener(DefaultTableModel model) {
        save.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                log.debug("Нажат кнопка 'Добавить лист'");
                try {
                    cnt_before_export = model.getRowCount();
                    int rows = cnt_after_import;
                    cnt_after_import = cnt_before_export;
                    Doctor curr_doctor = new Doctor();
                    Patient curr_patient = new Patient();

                    for (int row = rows; row < cnt_before_export; row++) {
                        String doctor_name = model.getValueAt(row, 2).toString();
                        String patient_name = model.getValueAt(row, 1).toString();
                        curr_doctor.setDoctor(curr_doctor.getIdByName(doctor_name));
                        curr_patient.setPatient(curr_patient.getIdByName(patient_name));
                        paper.setDoctor(curr_doctor);
                        paper.setPatient(curr_patient);
                        paper.setDateStart(model.getValueAt(row, 3).toString());
                        paper.setDateEnd(model.getValueAt(row, 4).toString());
                        if (curr_doctor.getPerson().getName() == null || curr_patient.getPerson().getName() == null)
                        {
                            JOptionPane.showMessageDialog(booklist, "Ошибка сохранения.\nПроверьте правильность введенных данных");
                        }
                        else {
                            Paper.export_to_db(paper);
                        }
                    }
                    JOptionPane.showMessageDialog(booklist, "Сохранено");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(booklist, "Ошибка сохранения.\nПроверьте правильность введенных данных");
                    ex.printStackTrace();
                }
            }
        });
    }


    public class PapComboBoxEditor extends DefaultCellEditor {
        public PapComboBoxEditor(JComboBox cb) {
            super(cb);
        }
    }


}
