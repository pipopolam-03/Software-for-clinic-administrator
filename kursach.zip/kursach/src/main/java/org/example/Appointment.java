package org.example;

import javax.persistence.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import org.apache.log4j.Logger;



@Entity
@Table(name = "appointments")
public class Appointment {
    private static final Logger log = Logger.getLogger(Appointment.class.getName());
    private static int cnt_after_import;
    private static int cnt_before_export;

    @Id
    @Column(name="a_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer a_id;

    public int getID() { return a_id; }
    public void setID(int a_id) { this.a_id = a_id; }

    @Column(name="appointment_date")
    private String appointment_date;
    public String getDate() { return appointment_date; }
    public void setDate(String appointment_date) { this.appointment_date = appointment_date; }


    private String time_from, time_to;

    @Column(name = "appointment_time_from")
    public String getTimeFrom() { return time_from; }
    public void setTimeFrom(String time_from) { this.time_from = time_from; }

    @Column(name = "appointment_time_to")
    public String getTimeTo() { return time_to; }
    public void setTimeTo(String time_to) { this.time_to = time_to; }

    @ManyToOne
    @JoinColumn(name = "appointment_doctor")

    private Doctor doctor;
    public Doctor getDoctor() {return doctor;}
    public void setDoctor(Doctor doctor) {this.doctor = doctor;}

    @ManyToOne
    @JoinColumn(name = "appointment_patient")

    private Patient patient;
    public Patient getPatient() {return patient;}
    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public void setApp(int id)
    {
        log.debug("Создан объект класса Appointment");
        this.setID(id);
        Doctor doctor = new Doctor();
        Patient patient = new Patient();

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC", "root", "pipopolam")) {
            String sqlQuery = "SELECT appointment_doctor_id, appointment_patient_id, " +
                    " appointment_time_from, appointment_time_to, appointment_date FROM appointments WHERE a_id = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setInt(1, id);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        this.setTimeFrom(resultSet.getString("appointment_time_from"));
                        this.setTimeTo(resultSet.getString("appointment_time_to"));
                        this.setDate(resultSet.getString("appointment_date"));
                        doctor.setDoctor(resultSet.getInt("appointment_doctor_id"));
                        this.setDoctor(doctor);
                        patient.setPatient(resultSet.getInt("appointment_patient_id"));
                        this.setPatient(patient);

                    }
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public static void fill_table(DefaultTableModel model) throws SQLException {
        log.debug("Начато заполнение таблицы");
        int rows = model.getRowCount();
        for (int i = 0; i < rows; i++) {
            model.removeRow(0);
        }

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            Statement statement = connection.createStatement();
            String sqlQuery = "SELECT a_id FROM appointments ";
            ResultSet resultSet = statement.executeQuery(sqlQuery);

            while (resultSet.next()) {
                Appointment app = new Appointment();
                int a_id = resultSet.getInt(1);
                app.setApp(a_id);
                String[] fields = {String.valueOf(a_id), app.getDate(), app.getTimeFrom() + " - " + app.getTimeTo(), app.getPatient().getPerson().getFullname(), app.getDoctor().getPerson().getFullname(), String.valueOf(a_id)};
                model.addRow(fields);
            }

            log.debug("Таблица успешно заполнена");

        } catch (SQLException e) {
            log.warn("Ошибка при заполнении таблицы", e);
            e.printStackTrace();
        }
        cnt_after_import = model.getRowCount();
    }

    public static void save_after_edit(String[] row, JFrame booklist) throws SQLException {
        int app_id = Integer.parseInt(row[0]);
        Appointment app = new Appointment();
        app.setApp(app_id);
        Doctor doc = new Doctor();
        Patient pat = new Patient();
        doc.setDoctor(doc.getIdByName(row[4]));
        pat.setPatient(pat.getIdByName(row[3]));
        app.setDoctor(doc);
        app.setPatient(pat);
        app.setDate(row[1]);
        String[] timeParts = row[2].split("-");
        String timeFrom = timeParts[0].trim();
        String timeTo = timeParts[1].trim();
        app.setTimeFrom(timeFrom);
        app.setTimeTo(timeTo);

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
            String updateQuery = "UPDATE appointments SET appointment_doctor_id=?, appointment_patient_id=?, appointment_date=?, appointment_time_from=?, appointment_time_to=? WHERE a_id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
                preparedStatement.setInt(1, doc.getID());
                preparedStatement.setInt(2, pat.getID());
                preparedStatement.setString(3, app.getDate());
                preparedStatement.setString(4, app.getTimeFrom());
                preparedStatement.setString(5, app.getTimeTo());
                preparedStatement.setInt(6, app_id);

                int rowsUpdated = preparedStatement.executeUpdate();

                if (rowsUpdated > 0) {
                    log.debug("Запись успешно обновлена");;
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(booklist, "Ошибка. Проверьте правильность введенных данных");
            log.warn("Ошибка обновления записи", e);
            e.printStackTrace();
        }
    }

    public static void save_from_table(DefaultTableModel model) throws SQLException {
        log.debug("Начат экспорт в базу данных");
        cnt_before_export = model.getRowCount();

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {

            for (int row = cnt_after_import; row < cnt_before_export; row++) {
                String dateValue = model.getValueAt(row, 1).toString();
                String fullTime = model.getValueAt(row, 2).toString();

                String[] timeParts = fullTime.split(" - ");
                String time_from = timeParts[0];
                String time_to = timeParts[1];

                String patientName = model.getValueAt(row, 3).toString();
                String doctorName = model.getValueAt(row, 4).toString();

                int patient_id = Patient.getIdByName(patientName);
                int doctor_id = Doctor.getIdByName(doctorName);

                if (patient_id != -1 && doctor_id != -1) {


                        String saveQuery = "INSERT INTO appointments (appointment_date, appointment_time_from, appointment_time_to, appointment_doctor_id, appointment_patient_id) " +
                                "VALUES (?, ?, ?, ?, ?)";

                        try (PreparedStatement preparedStatement = connection.prepareStatement(saveQuery)) {

                            preparedStatement.setString(1, dateValue);
                            preparedStatement.setString(2, time_from);
                            preparedStatement.setString(3, time_to);
                            preparedStatement.setInt(4, doctor_id);
                            preparedStatement.setInt(5, patient_id);

                            preparedStatement.executeUpdate();
                            log.debug("Экспорт в базу данных успешно завершен");
                        } catch (SQLException e) {
                            log.warn("Ошибка экспорта в базу данных", e);
                            e.printStackTrace();
                        }
                    }
                }
            }
        }



    public static void delete_one_app(JTable table, DefaultTableModel model) {
        int row = table.getSelectedRow();
        model.removeRow(row);
        log.debug("Удалена строка в таблице");
    }

}
