    package org.example;

    import net.sf.jasperreports.engine.*;
    import javax.persistence.*;
    import javax.swing.*;
    import javax.swing.table.DefaultTableModel;
    import java.io.File;
    import java.sql.*;
    import java.util.HashMap;
    import java.util.Map;
    import org.apache.log4j.Logger;
    import org.apache.log4j.PropertyConfigurator;


    @Entity
    @Table(name = "Papers")

    public class Paper {
        private static final Logger log = Logger.getLogger(Paper.class.getName());
        @Id
        @Column(name = "paper_id")
        @GeneratedValue(strategy = GenerationType.IDENTITY)

        private Integer paper_id;

        public int getID() {
            return paper_id;
        }

        public void setID(int paper_id) {
            this.paper_id = paper_id;
        }

        private Patient patient;

        public Patient getPatient() {
            return patient;
        }

        public void setPatient(Patient patient) {
            this.patient = patient;
        }

        private Doctor doctor;

        public Doctor getDoctor() {
            return doctor;
        }

        public void setDoctor(Doctor doctor) {
            this.doctor = doctor;
        }

        private String date_start, date_end;

        @Column(name = "paper_date_start")

        public String getDateStart() {
            return date_start;
        }

        public void setDateStart(String date_start) {
            this.date_start = date_start;
        }

        @Column(name = "paper_date_end")
        public String getDateEnd() {
            return date_end;
        }

        public void setDateEnd(String date_end) {
            this.date_end = date_end;
        }

        public void setPaper(int id) {
            log.debug("Создан новый объект классаа Paper");
            this.setID(id);
            Doctor doctor = new Doctor();
            Patient patient = new Patient();

            try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC", "root", "pipopolam")) {
                String sqlQuery = "SELECT paper_doctor_id, paper_patient_id, " +
                        "paper_date_start, paper_date_end FROM papers WHERE paper_id = ?";

                try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                    preparedStatement.setInt(1, id);

                    try (ResultSet resultSet = preparedStatement.executeQuery()) {
                        if (resultSet.next()) {
                            this.setDateEnd(resultSet.getString("paper_date_end"));
                            this.setDateStart(resultSet.getString("paper_date_start"));
                            doctor.setDoctor(resultSet.getInt("paper_doctor_id"));
                            this.setDoctor(doctor);
                            patient.setPatient(resultSet.getInt("paper_patient_id"));
                            this.setPatient(patient);

                        }
                    }
                } catch (SQLException e) {

                    throw new RuntimeException(e);

                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }


        public static void import_from_db(DefaultTableModel model) {
            log.debug("Начат импорт записей в таблицу больничных листов из базы данных");
            try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
                String sqlQuery = "SELECT paper_id, paper_patient_id,  paper_doctor_id, paper_date_start, paper_date_end " +
                        "FROM papers";

                PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
                ResultSet resultSet = preparedStatement.executeQuery();


                while (resultSet.next()) {
                    Integer id = resultSet.getInt(1);
                    Integer paper_patient_id = resultSet.getInt(2);
                    Integer paper_doctor_id = resultSet.getInt(3);
                    String paper_date_start = resultSet.getString(4);
                    String paper_date_end = resultSet.getString(5);
                    String patient_name = Patient.getNameById(paper_patient_id);
                    String doctor_name = Doctor.getNameById(paper_doctor_id);
                    String[] fields = {String.valueOf(id), patient_name, doctor_name, paper_date_start, paper_date_end};
                    model.addRow(fields);
                }
                log.debug("Успешно завершен импорт записей в таблицу больничных листов из базы данных");

            } catch (SQLException e) {
                log.warn("Ошибка импорта записей в таблицу больничных листов из базы данных", e);
                e.printStackTrace();
            }


        }


        public static void fillJasperReport(Paper paper) {
            log.debug("Начато формирование больничного листа");
            try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd", "root", "pipopolam")) {
                String sqlQuery = "SELECT paper_patient_id, paper_doctor_id, paper_date_start, paper_date_end FROM papers WHERE paper_id = ?";

                try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                    preparedStatement.setInt(1, paper.getID());

                    try (ResultSet resultSet = preparedStatement.executeQuery()) {
                        if (resultSet.next()) {

                            JasperReport jasperReport = JasperCompileManager.compileReport(
                                    new File("C:\\Users\\pipop\\IdeaProjects\\kursach\\src\\main\\resources\\paper.jrxml").getAbsolutePath()
                            );

                            Map<String, Object> parameters = new HashMap<>();
                            parameters.put("id", paper.getID());
                            parameters.put("patient", paper.patient.getPerson().getFullname());
                            parameters.put("doctor", paper.doctor.getPerson().getFullname());
                            parameters.put("start", paper.date_start);
                            parameters.put("end", paper.date_end);
                            parameters.put("district", paper.patient.getDistrict());
                            parameters.put("diseases", paper.patient.form_diseases());

                            JasperPrint jasperPrint = JasperFillManager.fillReport(
                                    jasperReport,
                                    parameters,
                                    new JREmptyDataSource()
                            );

                            JasperExportManager.exportReportToPdfFile(jasperPrint, "output.pdf");


                        }
                        log.debug("Больничный лист успешно заполнен");
                    } catch (JRException e) {
                        System.out.println("Ошибка при заполнении справки " + e.getMessage());
                        log.warn("Ошибка заполнения больничного листа", e);
                        throw new RuntimeException(e);
                    }
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        public static void export_to_db(Paper paper) throws SQLException {
            log.debug("Начат экспорт записей больничных листов в базу данных");
            try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
                String insertQuery = "INSERT INTO papers (paper_patient_id, paper_doctor_id, paper_date_start, paper_date_end) VALUES (?, ?, ?, ?)";
                try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
                    preparedStatement.setInt(1, paper.patient.getID());
                    preparedStatement.setInt(2, paper.doctor.getID());
                    preparedStatement.setString(3, paper.date_start);
                    preparedStatement.setString(4, paper.date_end);

                    preparedStatement.executeUpdate();

                    log.debug("Успешно завершен экспорт записей больничных листов в базу данных");

                } catch (SQLException ex) {
                    log.warn("Ошибка экспорта записей больничных листов в базу данных", ex);
                    ex.printStackTrace();
                    throw new RuntimeException("Error during INSERT operation", ex);
                }
            }

        }



        public static void delete_paper(int paper_id) throws SQLException {
            log.debug("Удален больничный лист");
            try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
                connection.setAutoCommit(false);

                try {

                    String deleteAppointmentsQuery = "DELETE FROM papers WHERE paper_id = ?";
                    try (PreparedStatement preparedStatement = connection.prepareStatement(deleteAppointmentsQuery)) {
                        preparedStatement.setInt(1, paper_id);
                        preparedStatement.executeUpdate();
                    }

                    connection.commit();
                } catch (SQLException e) {
                    connection.rollback();
                    throw e;
                }
            }
        }

        public static void save_after_edit(String[] row, JFrame booklist) throws SQLException {
            int paper_id = -1;
            Doctor doc = new Doctor();
            Paper paper = new Paper();
            Patient pat = new Patient();
            paper_id = Integer.parseInt(row[0]);
            paper.setPaper(paper_id);
            doc.setDoctor(Doctor.getIdByName(row[2]));
            paper.setDoctor(doc);
            pat.setPatient(Patient.getIdByName(row[1]));
            paper.setPatient(pat);
            paper.setDateStart(row[3]);
            paper.setDateEnd(row[4]);

            if (doc.getPerson() == null || pat.getPerson() == null)
            {
                JOptionPane.showMessageDialog(booklist, "Ошибка обновления.\nПроверьте правильность введенных данных");
            }
            else {

                try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/clinic_bd?serverTimezone=UTC&useLegacyDatetimeCode=false", "root", "pipopolam")) {
                    String updateQuery = "UPDATE papers SET paper_doctor_id=?, paper_patient_id=?, paper_date_start=?, paper_date_end=? WHERE paper_id=?";
                    try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
                        preparedStatement.setInt(1, doc.getID());
                        preparedStatement.setInt(2, pat.getID());
                        preparedStatement.setString(3, paper.getDateStart());
                        preparedStatement.setString(4, paper.getDateEnd());
                        preparedStatement.setInt(5, paper_id);

                        int rowsUpdated = preparedStatement.executeUpdate();

                        if (rowsUpdated > 0) {
                            log.debug("Запись успешно обновлена");;
                        }
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(booklist, "Ошибка. Проверьте правильность введенных данных");
                    log.warn("Ошибка обновления записи", e);
                    e.printStackTrace();
                }
            }

        }



    }
