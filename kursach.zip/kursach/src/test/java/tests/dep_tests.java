package tests;

import org.example.Department;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;
public class dep_tests {
    /**
     * Метод для вывода сообщения о начале тестирования
     */
    @BeforeAll
    public static void allTestsStarted() {
        System.out.println("Начало тестирования");
    }

    /**
     * Метод для вывода сообщения о конце тестирования
     */
    @AfterAll
    public static void allTestsFinished() {
        System.out.println("Конец тестирования");
    }

    /**
     * Метод для вывода сообщения о запуске теста
     */
    @BeforeEach
    public void testStarted() {
        System.out.println("Запуск теста");
    }

    /**
     * Метод для вывода сообщения о завершении теста
     */
    @AfterEach
    public void testFinished() {
        System.out.println("Завершение теста");
    }

        @Test
        void testSetDep() {
            Department department = new Department();
            department.setDep(1);
            assertEquals(1, department.getID());
            assertEquals("Терапевтическое отделение", department.getName());
        }

        @Test
        void testGetIdByName() {
            int actualId = Department.getIdByName("Терапевтическое отделение");
            assertEquals(1, actualId);
        }

        @Test
        void testGetIdByWrongName() {
            int expectedId = -1;
            int actualId = Department.getIdByName("Колбасный отдел");
            assertEquals(expectedId, actualId);
        }
    }


