package tests;
import org.example.Disease;
import org.junit.jupiter.api.*;

import javax.swing.table.DefaultTableModel;

import static org.junit.jupiter.api.Assertions.*;

public class disease_tests {

    /**
     * Метод для вывода сообщения о начале тестирования
     */
    @BeforeAll
    public static void allTestsStarted() {
        System.out.println("Начало тестирования");
    }

    /**
     * Метод для вывода сообщения о конце тестирования
     */
    @AfterAll
    public static void allTestsFinished() {
        System.out.println("Конец тестирования");
    }

    /**
     * Метод для вывода сообщения о запуске теста
     */
    @BeforeEach
    public void testStarted() {
        System.out.println("Запуск теста");
    }

    /**
     * Метод для вывода сообщения о завершении теста
     */
    @AfterEach
    public void testFinished() {
        System.out.println("Завершение теста");
    }

    @Test
    void testGetIdByName() {
        String diseaseName = "Грипп";
        assertEquals(1, Disease.getIdByName(diseaseName));
    }


    @Test
    void testCountDiseases() {
        Disease disease = new Disease();
        disease.setDisease(1);
        assertEquals(1, Disease.count_diseases(disease));
    }

    @Test
    void testExportToDb() {
        DefaultTableModel model = new DefaultTableModel();
        int departmentId = 1;
        assertDoesNotThrow(() -> Disease.export_to_db(model, departmentId));
    }
}
