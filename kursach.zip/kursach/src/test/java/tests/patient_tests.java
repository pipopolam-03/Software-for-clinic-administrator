package tests;
import org.example.Patient;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

public class patient_tests
{
    /**
     * Метод для вывода сообщения о начале тестирования
     */
    @BeforeAll
    public static void allTestsStarted() {
        System.out.println("Начало тестирования");
    }

    /**
     * Метод для вывода сообщения о конце тестирования
     */
    @AfterAll
    public static void allTestsFinished() {
        System.out.println("Конец тестирования");
    }

    /**
     * Метод для вывода сообщения о запуске теста
     */
    @BeforeEach
    public void testStarted() {
        System.out.println("Запуск теста");
    }

    /**
     * Метод для вывода сообщения о завершении теста
     */
    @AfterEach
    public void testFinished() {
        System.out.println("Завершение теста");
    }

    @Test
    void testGetNameById() {
        int patientId = 1;
        assertEquals("Алексей Петрович Сидоров", Patient.getNameById(patientId));
    }

    @Test
    void testGetIdByName() {
        String patientFullName = "Алексей Петрович Сидоров";
        assertEquals(1, Patient.getIdByName(patientFullName));
    }

    @Test
    void testFormDiseases() {
        Patient patient = new Patient();
        patient.setPatient(1);
        assertEquals("Грипп ", patient.form_diseases());
    }

}
