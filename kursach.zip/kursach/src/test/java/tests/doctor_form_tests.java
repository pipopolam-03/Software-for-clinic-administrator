package tests;
import org.example.Doctors_form;
import org.junit.jupiter.api.*;


import static org.junit.jupiter.api.Assertions.*;

public class doctor_form_tests {

    /**
     * Метод для вывода сообщения о начале тестирования
     */
    @BeforeAll
    public static void allTestsStarted() {
        System.out.println("Начало тестирования");
    }

    /**
     * Метод для вывода сообщения о конце тестирования
     */
    @AfterAll
    public static void allTestsFinished() {
        System.out.println("Конец тестирования");
    }

    /**
     * Метод для вывода сообщения о запуске теста
     */
    @BeforeEach
    public void testStarted() {
        System.out.println("Запуск теста");
    }

    /**
     * Метод для вывода сообщения о завершении теста
     */
    @AfterEach
    public void testFinished() {
        System.out.println("Завершение теста");
    }

    @Test
    void testShowForm() {
        Doctors_form doctorsForm = new Doctors_form();
        assertDoesNotThrow(doctorsForm::show_form);
    }



}

