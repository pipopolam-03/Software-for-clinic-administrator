package tests;
import org.example.Department;
import org.example.Doctor;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;
public class doctor_tests {
    /**
     * Метод для вывода сообщения о начале тестирования
     */
    @BeforeAll
    public static void allTestsStarted() {
        System.out.println("Начало тестирования");
    }

    /**
     * Метод для вывода сообщения о конце тестирования
     */
    @AfterAll
    public static void allTestsFinished() {
        System.out.println("Конец тестирования");
    }

    /**
     * Метод для вывода сообщения о запуске теста
     */
    @BeforeEach
    public void testStarted() {
        System.out.println("Запуск теста");
    }

    /**
     * Метод для вывода сообщения о завершении теста
     */
    @AfterEach
    public void testFinished() {
        System.out.println("Завершение теста");
    }

    @Test
    void testGetIdByName() {
        // Assuming there is a doctor with known data in the database
        int expectedId = 2;
        int actualId = Doctor.getIdByName("Елена Сергеевна Петрова");
        assertEquals(expectedId, actualId);
    }

    @Test
    void testGetNameById() {
        // Assuming there is a doctor with known data in the database
        String expectedName = "Елена Сергеевна Петрова";
        String actualName = Doctor.getNameById(2);
        assertEquals(expectedName, actualName);
    }
}
