package tests;

import org.example.Appointment_form;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.AfterAll;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

public class app_form_tests {
    /**
     * Метод для вывода сообщения о начале тестирования
     */
    @BeforeAll
    public static void allTestsStarted() {
        System.out.println("Начало тестирования");
    }

    /**
     * Метод для вывода сообщения о конце тестирования
     */
    @AfterAll
    public static void allTestsFinished() {
        System.out.println("Конец тестирования");
    }

    /**
     * Метод для вывода сообщения о запуске теста
     */
    @BeforeEach
    public void testStarted() {
        System.out.println("Запуск теста");
    }

    /**
     * Метод для вывода сообщения о завершении теста
     */
    @AfterEach
    public void testFinished() {
        System.out.println("Завершение теста");
    }

        @Test
        void testShowApps() {

            assertDoesNotThrow(() -> new Appointment_form().show_apps());
        }

    }



