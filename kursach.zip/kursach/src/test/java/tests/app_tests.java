package tests;
import org.example.Appointment;
import org.junit.jupiter.api.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import static org.junit.jupiter.api.Assertions.*;

public class app_tests {

    /**
     * Метод для вывода сообщения о начале тестирования
     */
    @BeforeAll
    public static void allTestsStarted() {
        System.out.println("Начало тестирования");
    }

    /**
     * Метод для вывода сообщения о конце тестирования
     */
    @AfterAll
    public static void allTestsFinished() {
        System.out.println("Конец тестирования");
    }

    /**
     * Метод для вывода сообщения о запуске теста
     */
    @BeforeEach
    public void testStarted() {
        System.out.println("Запуск теста");
    }

    /**
     * Метод для вывода сообщения о завершении теста
     */
    @AfterEach
    public void testFinished() {
        System.out.println("Завершение теста");
    }


    @Test
    void testFillTable() {
        DefaultTableModel model = new DefaultTableModel();
        assertDoesNotThrow(() -> Appointment.fill_table(model));
        assertTrue(model.getRowCount() > 0);
    }

    @Test
    void testSaveFromTable() {
        DefaultTableModel model = new DefaultTableModel();
        model.addRow(new Object[]{"2023-01-01", "09:00 - 10:00", "John Doe", "Dr. Smith", "1"});
        assertDoesNotThrow(() -> Appointment.save_from_table(model));
    }

}
