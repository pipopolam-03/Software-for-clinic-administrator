package tests;
import org.example.Doctor;
import org.example.Schedule;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;


public class schedule_tests {
    /**
     * Метод для вывода сообщения о начале тестирования
     */
    @BeforeAll
    public static void allTestsStarted() {
        System.out.println("Начало тестирования");
    }

    /**
     * Метод для вывода сообщения о конце тестирования
     */
    @AfterAll
    public static void allTestsFinished() {
        System.out.println("Конец тестирования");
    }

    /**
     * Метод для вывода сообщения о запуске теста
     */
    @BeforeEach
    public void testStarted() {
        System.out.println("Запуск теста");
    }

    /**
     * Метод для вывода сообщения о завершении теста
     */
    @AfterEach
    public void testFinished() {
        System.out.println("Завершение теста");
    }

    @Test
    void testShowDoctorSchedule() {
        Doctor doctor = new Doctor();
        doctor.setID(1);
        assertDoesNotThrow(() -> Schedule.show_doctor_schedule(doctor));
    }
}
