package tests;
import org.example.Doctor;
import org.example.Paper;
import org.example.Patient;
import org.junit.jupiter.api.*;

import javax.swing.table.DefaultTableModel;

import static org.junit.jupiter.api.Assertions.*;

public class paper_tests {
    /**
     * Метод для вывода сообщения о начале тестирования
     */
    @BeforeAll
    public static void allTestsStarted() {
        System.out.println("Начало тестирования");
    }

    /**
     * Метод для вывода сообщения о конце тестирования
     */
    @AfterAll
    public static void allTestsFinished() {
        System.out.println("Конец тестирования");
    }

    /**
     * Метод для вывода сообщения о запуске теста
     */
    @BeforeEach
    public void testStarted() {
        System.out.println("Запуск теста");
    }

    /**
     * Метод для вывода сообщения о завершении теста
     */
    @AfterEach
    public void testFinished() {
        System.out.println("Завершение теста");
    }

    @Test
    void testImportFromDB() {
        DefaultTableModel model = new DefaultTableModel();
        Paper.import_from_db(model);
        assertTrue(model.getRowCount() > 0);
    }

    @Test
    void testFillJasperReport() {
        Paper paper = new Paper();
        paper.setPaper(1);
        paper.fillJasperReport(paper);

    }

    @Test
    void testExportToDB() {
        Paper paper = new Paper();
        Patient patient = new Patient();
        patient.setPatient(1);
        Doctor doctor = new Doctor();
        doctor.setDoctor(1);
        paper.setPatient(patient);
        paper.setDoctor(doctor);
        paper.setDateStart("2023-10-15");
        paper.setDateEnd("2023-10-25");
        assertDoesNotThrow(() -> Paper.export_to_db(paper));
    }

}
